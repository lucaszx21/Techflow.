<?php
// includes/sidebar.php
require_once __DIR__ . '/../auth.php';
$current_page = basename($_SERVER['PHP_SELF']);
?>
<aside class="sidebar">
    <div class="logo">
        <span class="material-icons">layers</span>
        <h2>TechFlow Core</h2>
    </div>
    
    <nav class="nav-menu" style="display: flex; flex-direction: column; height: calc(100% - 70px); justify-content: space-between;">
        <!-- Grupo de enlaces superiores -->
        <div class="nav-links-top" style="display: flex; flex-direction: column; gap: 4px;">
            
            <?php if (esAdmin() || esTecnico()): ?>
                <a href="index.php" class="<?php echo $current_page == 'index.php' ? 'active' : ''; ?>">
                    <span class="material-icons">grid_view</span>
                    <span class="lang" data-es="Métricas Base" data-en="Base Metrics">Métricas Base</span>
                </a>

                <a href="inventario.php" class="<?php echo $current_page == 'inventario.php' ? 'active' : ''; ?>">
                    <span class="material-icons">computer</span>
                    <span class="lang" data-es="Inventario TI" data-en="IT Assets">Inventario TI</span>
                </a>
            <?php endif; ?>

            <a href="tickets.php" class="<?php echo $current_page == 'tickets.php' ? 'active' : ''; ?>">
                <span class="material-icons">confirmation_number</span>
                <span class="lang" data-es="Mesa de Soporte" data-en="Support Desk">Mesa de Soporte</span>
            </a>

            <?php if (esAdmin() || esTecnico()): ?>
                <a href="caja_tickets.php" class="<?php echo $current_page == 'caja_tickets.php' ? 'active' : ''; ?>" style="display: flex; align-items: center; gap: 12px; width: 100%; box-sizing: border-box;">
                    <span class="material-icons">all_inbox</span>
                    <span class="lang" data-es="Caja de Tickets" data-en="Tickets Inbox">Caja de Tickets</span>
                </a>
            <?php endif; ?>

            <?php if (esAdmin()): ?>
                <a href="usuarios.php" class="<?php echo $current_page == 'usuarios.php' ? 'active' : ''; ?>">
                    <span class="material-icons">manage_accounts</span>
                    <span class="lang" data-es="Usuarios y Roles" data-en="Users & Roles">Usuarios y Roles</span>
                </a>
            <?php endif; ?>
        </div>

        <!-- Enlace de Desconexión inferior (Siempre visible) -->
        <div class="nav-links-bottom" style="padding-top: 20px; margin-top: auto;">
            <a href="logout.php" class="logout-link" style="color: #fda4af; display: flex; align-items: center; gap: 10px; text-decoration: none; padding: 10px 16px;">
                <span class="material-icons">power_settings_new</span>
                <span class="lang" data-es="Desconectarse" data-en="Logout">Desconectarse</span>
            </a>
        </div>
        
    </nav>
</aside>