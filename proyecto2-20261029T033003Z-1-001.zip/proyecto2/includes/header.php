<?php
// includes/header.php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
// Asegurar que las variables de sesión existan para el entorno visual
$nombre_header = isset($_SESSION['usuario_nombre']) ? $_SESSION['usuario_nombre'] : 'Invitado';
$rol_header = isset($_SESSION['usuario_rol']) ? $_SESSION['usuario_rol'] : 'Standard';
?>
<style>
    /* Selector de idioma de la barra superior (controlado por global.js) */
    .header-lang-selector .btn-lang {
        cursor: pointer;
        background: none;
        border: none;
        padding: 2px 4px;
        font-weight: 600;
        font-size: 0.9rem;
        font-family: inherit;
        color: var(--text-muted, #94a3b8);
        transition: color 0.15s ease;
    }
    .header-lang-selector .btn-lang:hover,
    .header-lang-selector .btn-lang.active {
        color: #ffffff;
    }
</style>
<div class="header-right" style="display: flex; align-items: center; gap: 20px; margin-left: auto;">
    <div class="header-lang-selector" data-no-i18n style="display: flex; gap: 10px;">
        <button type="button" id="btn-es" class="btn-lang active">ES</button>
        <button type="button" id="btn-en" class="btn-lang">EN</button>
    </div>

    <div class="user-profile" style="display: flex; align-items: center; gap: 10px;">
        <span class="material-icons" style="font-size: 32px; color: var(--text-muted)">account_circle</span>
        <div style="display: flex; flex-direction: column;">
            <span style="font-weight: 600; color: var(--text-main); font-size: 0.9rem;"><?php echo htmlspecialchars($nombre_header); ?></span>
            <small style="color: var(--text-muted); font-size: 0.75rem; font-weight: 500;"><?php echo htmlspecialchars($rol_header); ?></small>
        </div>
    </div>
</div>
