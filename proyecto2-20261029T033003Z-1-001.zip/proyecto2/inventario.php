<?php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once 'conexion.php';
require_once 'auth.php';
verificarSesion();

if (esStandard()) {
    header("Location: tickets.php");
    exit();
}

$sql = "SELECT * FROM EQUIPO ORDER BY id_equipo DESC";
$resultado = $conexion->query($sql);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Inventario TI - TechFlow</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <script src="global.js"></script>

    <style>
        .inventario-dark th {
            background: #0f172a !important;
            color: #94a3b8 !important;
            border-bottom: 1px solid #334155 !important;
        }
        .inventario-dark td {
            border-bottom: 1px solid #334155 !important;
        }
        .inventario-dark .data-section {
            background-color: transparent !important;
            border: none !important;
        }
    </style>
</head>
<body style="background-color: #0f172a !important; margin: 0; font-family: system-ui, sans-serif; color: #ffffff !important;">
    <div class="dashboard-container">
        <?php include 'includes/sidebar.php'; ?>

        <main class="main-content" style="height: 100vh; overflow-y: auto;">
            <header class="top-header" style="display: flex; justify-content: space-between; align-items: center; padding: 15px 30px; background: #1e293b !important; border-bottom: 1px solid #334155 !important;">
                <div class="search-bar-container" style="display: flex; align-items: center; background: #0f172a !important; border: 1px solid #334155 !important; border-radius: 8px; padding: 6px 12px; width: 300px;">
                    <span class="material-icons" style="font-size:18px; color:#94a3b8; margin-right: 8px;">search</span>
                    <input type="text" id="asset-search" placeholder="Filtrar hardware..." style="background: transparent; border: none; color: #ffffff !important; outline: none; width: 100%; font-size: 0.9rem;">
                </div>
                <?php include 'includes/header.php'; ?>
            </header>

            <div class="content-body inventario-dark" style="padding: 30px; background: #0f172a !important; min-height: calc(100vh - 60px);">
                <section class="data-section" style="background: transparent !important; border: none !important;">

                    <?php if (isset($_GET['success'])): ?>
                        <div style="background: rgba(34, 197, 94, 0.15); border: 1px solid #22c55e; color: #4ade80; padding: 12px; border-radius: 8px; font-size: 0.9rem; margin-bottom: 20px;">
                            ¡Equipo registrado correctamente en la base de datos!
                        </div>
                    <?php endif; ?>

                    <?php
                    $errores_inv = [
                        'duplicado' => 'Error: El código de inventario (Asset Tag) ya existe.',
                        'vacios'    => 'Completa los campos obligatorios.',
                        'sesion'    => 'Sesión inválida. Recarga la página e inténtalo de nuevo.',
                        'db'        => 'Error al guardar el equipo en la base de datos.'
                    ];
                    if (isset($_GET['error']) && isset($errores_inv[$_GET['error']])): ?>
                        <div style="background: rgba(239, 68, 68, 0.15); border: 1px solid #ef4444; color: #f87171; padding: 12px; border-radius: 8px; font-size: 0.9rem; margin-bottom: 20px;">
                            <?php echo esc($errores_inv[$_GET['error']]); ?>
                        </div>
                    <?php endif; ?>

                    <div class="section-header" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px;">
                        <h2 style="color: #ffffff !important; margin: 0; font-size: 1.5rem; font-weight: 600;">Inventario de Equipos Tecnológicos</h2>
                        <?php if (esAdmin()): ?>
                            <button id="btn-add-asset" class="btn-primary" onclick="mostrarModalEquipo()" style="display: flex; align-items: center; gap: 8px; background: #3b82f6 !important; color: white !important; border: none !important; padding: 10px 16px; border-radius: 8px; font-weight: 600; cursor: pointer; transition: background 0.2s;">
                                <span class="material-icons" style="font-size:18px">add</span>
                                <span>Registrar nuevo equipo</span>
                            </button>
                        <?php endif; ?>
                    </div>

                    <div class="table-container" style="background: #1e293b !important; border: 1px solid #334155 !important; border-radius: 12px !important; padding: 12px !important; box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.4) !important; overflow-x: auto !important;">
                        <div style="background: #151f32 !important; border-radius: 8px !important; overflow: hidden !important;">
                            <table style="width: 100% !important; border-collapse: collapse !important; text-align: left !important; background: #151f32 !important;">
                                <thead>
                                    <tr style="background: #0f172a !important;">
                                        <th style="padding: 16px; font-size: 0.85rem; font-weight: 600; text-transform: uppercase; letter-spacing: 0.05em;">Asset Tag</th>
                                        <th style="padding: 16px; font-size: 0.85rem; font-weight: 600; text-transform: uppercase; letter-spacing: 0.05em;">Especificaciones</th>
                                        <th style="padding: 16px; font-size: 0.85rem; font-weight: 600; text-transform: uppercase; letter-spacing: 0.05em;">Trazabilidad</th>
                                        <th style="padding: 16px; font-size: 0.85rem; font-weight: 600; text-transform: uppercase; letter-spacing: 0.05em;">Estado</th>
                                    </tr>
                                </thead>
                                <tbody id="inventory-table-body" style="background: #151f32 !important;">
                                    <?php if ($resultado && $resultado->num_rows > 0): ?>
                                        <?php while($equipo = $resultado->fetch_assoc()): ?>
                                            <tr class="fila-equipo" style="background: #151f32 !important; transition: background 0.2s;">
                                                <td style="padding: 16px;">
                                                    <div style="font-weight: 600; color: #ffffff !important;">
                                                        <?php echo esc($equipo['codigo_inventario']); ?>
                                                    </div>
                                                    <div style="font-size: 0.75rem; color: #94a3b8 !important; margin-top: 2px;">
                                                        S/N: <?php echo esc($equipo['numero_serie'] ? $equipo['numero_serie'] : 'N/A'); ?>
                                                    </div>
                                                </td>

                                                <td style="padding: 16px;">
                                                    <div style="font-weight: 500; color: #ffffff !important;">
                                                        <?php echo esc($equipo['nombre_equipo']); ?>
                                                    </div>
                                                    <div style="font-size: 0.8rem; color: #94a3b8 !important; margin-top: 2px;">
                                                        <?php echo esc($equipo['tipo_equipo'] . " — " . $equipo['marca'] . " " . $equipo['modelo']); ?>
                                                    </div>
                                                </td>

                                                <td style="padding: 16px;">
                                                    <div style="font-size: 0.85rem; color: #e2e8f0 !important; display: flex; align-items: center; gap: 4px;">
                                                        <span class="material-icons" style="font-size: 16px; color: #94a3b8 !important;">place</span>
                                                        <?php echo esc($equipo['ubicacion'] ? $equipo['ubicacion'] : 'No asignada'); ?>
                                                    </div>
                                                </td>

                                                <td style="padding: 16px;">
                                                    <?php
                                                    $est = strtolower($equipo['estado']);
                                                    $badgeColor = "rgba(148, 163, 184, 0.15)"; $textColor = "#94a3b8";
                                                    if ($est === 'operativo') { $badgeColor = "rgba(34, 197, 94, 0.15)"; $textColor = "#4ade80"; }
                                                    elseif ($est === 'mantenimiento') { $badgeColor = "rgba(234, 179, 8, 0.15)"; $textColor = "#facc15"; }
                                                    elseif ($est === 'de baja') { $badgeColor = "rgba(239, 68, 68, 0.15)"; $textColor = "#f87171"; }
                                                    ?>
                                                    <span style="background: <?php echo $badgeColor; ?> !important; color: <?php echo $textColor; ?> !important; padding: 6px 12px; border-radius: 20px; font-size: 0.75rem; font-weight: 600; display: inline-block;">
                                                        <?php echo esc($equipo['estado']); ?>
                                                    </span>
                                                </td>
                                            </tr>
                                        <?php endwhile; ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>

                        <?php if (!$resultado || $resultado->num_rows === 0): ?>
                            <div id="inventory-empty-state" class="empty-state-container" style="display: flex; flex-direction: column; align-items: center; padding: 60px; text-align: center; background: #151f32 !important; border: none !important;">
                                <span class="material-icons" style="font-size: 48px; color: #334155; margin-bottom: 12px;">inventory_2</span>
                                <h4 style="color: #94a3b8; margin: 0; font-weight: 500;">El inventario está en blanco</h4>
                            </div>
                        <?php endif; ?>
                    </div>
                </section>
            </div>
        </main>
    </div>

    <div id="modal-equipo" style="display:none; position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(15, 23, 42, 0.75); z-index:1000; align-items:center; justify-content:center; backdrop-filter: blur(4px);">
        <div style="background:#1e293b !important; border: 1px solid #334155 !important; padding:28px; border-radius:12px; width:460px; box-shadow:0 20px 25px -5px rgba(0,0,0,0.5); max-height:90vh; overflow-y:auto; color: #ffffff !important;">
            <h3 style="margin-top:0; margin-bottom:20px; color: #ffffff !important; font-size: 1.25rem; font-weight: 600;">Registrar Nuevo Activo TI</h3>

            <form action="guardar_equipo.php" method="POST">
                <?php echo csrf_campo(); ?>
                <div class="form-group" style="margin-bottom:14px;">
                    <label style="display:block; margin-bottom:6px; font-size:0.85rem; font-weight:600; color: #94a3b8 !important;">Código Inventario (Asset Tag)*</label>
                    <input type="text" name="codigo_inventario" required placeholder="Ej: INV-2026-001" style="width:100%; padding:10px; background: #0f172a !important; border:1px solid #334155 !important; border-radius:6px; color:#ffffff !important; box-sizing: border-box; outline:none; font-size:0.9rem;">
                </div>

                <div class="form-group" style="margin-bottom:14px;">
                    <label style="display:block; margin-bottom:6px; font-size:0.85rem; font-weight:600; color: #94a3b8 !important;">Nombre del Equipo*</label>
                    <input type="text" name="nombre_equipo" required placeholder="Ej: Laptop HP ProBook" style="width:100%; padding:10px; background: #0f172a !important; border:1px solid #334155 !important; border-radius:6px; color:#ffffff !important; box-sizing: border-box; outline:none; font-size:0.9rem;">
                </div>

                <div class="form-group" style="margin-bottom:14px;">
                    <label style="display:block; margin-bottom:6px; font-size:0.85rem; font-weight:600; color: #94a3b8 !important;">Tipo de Equipo</label>
                    <input type="text" name="tipo_equipo" placeholder="Ej: Portátil, Servidor, Switch" style="width:100%; padding:10px; background: #0f172a !important; border:1px solid #334155 !important; border-radius:6px; color:#ffffff !important; box-sizing: border-box; outline:none; font-size:0.9rem;">
                </div>

                <div style="display:flex; gap:12px; margin-bottom:14px;">
                    <div style="flex:1;">
                        <label style="display:block; margin-bottom:6px; font-size:0.85rem; font-weight:600; color: #94a3b8 !important;">Marca</label>
                        <input type="text" name="marca" placeholder="Ej: HP" style="width:100%; padding:10px; background: #0f172a !important; border:1px solid #334155 !important; border-radius:6px; color:#ffffff !important; box-sizing: border-box; outline:none; font-size:0.9rem;">
                    </div>
                    <div style="flex:1;">
                        <label style="display:block; margin-bottom:6px; font-size:0.85rem; font-weight:600; color: #94a3b8 !important;">Modelo</label>
                        <input type="text" name="modelo" placeholder="Ej: 450 G8" style="width:100%; padding:10px; background: #0f172a !important; border:1px solid #334155 !important; border-radius:6px; color:#ffffff !important; box-sizing: border-box; outline:none; font-size:0.9rem;">
                    </div>
                </div>

                <div class="form-group" style="margin-bottom:14px;">
                    <label style="display:block; margin-bottom:6px; font-size:0.85rem; font-weight:600; color: #94a3b8 !important;">Número de Serie</label>
                    <input type="text" name="numero_serie" placeholder="Ej: CND12345XYZ" style="width:100%; padding:10px; background: #0f172a !important; border:1px solid #334155 !important; border-radius:6px; color:#ffffff !important; box-sizing: border-box; outline:none; font-size:0.9rem;">
                </div>

                <div style="display:flex; gap:12px; margin-bottom:24px;">
                    <div style="flex:1;">
                        <label style="display:block; margin-bottom:6px; font-size:0.85rem; font-weight:600; color: #94a3b8 !important;">Ubicación</label>
                        <input type="text" name="ubicacion" placeholder="Ej: Oficina Central" style="width:100%; padding:10px; background: #0f172a !important; border:1px solid #334155 !important; border-radius:6px; color:#ffffff !important; box-sizing: border-box; outline:none; font-size:0.9rem;">
                    </div>
                    <div style="flex:1;">
                        <label style="display:block; margin-bottom:6px; font-size:0.85rem; font-weight:600; color: #94a3b8 !important;">Estado Inicial</label>
                        <select name="estado" style="width:100%; padding:10px; background: #0f172a !important; border:1px solid #334155 !important; border-radius:6px; color:#ffffff !important; box-sizing: border-box; outline:none; cursor:pointer; font-size:0.9rem;">
                            <option value="Operativo" style="background:#1e293b; color:#ffffff;">Operativo</option>
                            <option value="Mantenimiento" style="background:#1e293b; color:#ffffff;">Mantenimiento</option>
                            <option value="De baja" style="background:#1e293b; color:#ffffff;">De baja</option>
                        </select>
                    </div>
                </div>

                <div style="display:flex; gap:10px; justify-content:flex-end;">
                    <button type="button" onclick="cerrarModalEquipo()" style="padding:10px 18px; background:#334155; border:none; border-radius:8px; cursor:pointer; font-weight:600; color:#e2e8f0; transition: background 0.2s;">Cancelar</button>
                    <button type="submit" style="padding:10px 18px; background:#3b82f6; border:none; border-radius:8px; cursor:pointer; font-weight:600; color:#ffffff; transition: background 0.2s;">Guardar Equipo</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        function mostrarModalEquipo() { document.getElementById('modal-equipo').style.display = 'flex'; }
        function cerrarModalEquipo() { document.getElementById('modal-equipo').style.display = 'none'; }

        document.addEventListener('keydown', e => { if (e.key === 'Escape') cerrarModalEquipo(); });

        document.getElementById('asset-search').addEventListener('input', function () {
            const q = this.value.toLowerCase().trim();
            document.querySelectorAll('#inventory-table-body .fila-equipo').forEach(fila => {
                fila.style.display = fila.innerText.toLowerCase().includes(q) ? '' : 'none';
            });
        });
    </script>
</body>
</html>
