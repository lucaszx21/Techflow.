<?php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once 'conexion.php';
require_once 'auth.php';

if (isset($_SESSION['usuario_id'], $_SESSION['usuario_rol'])) {
    header("Location: " . (esStandard() ? "tickets.php" : "index.php"));
    exit();
}

$error_message = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = isset($_POST['email']) ? trim($_POST['email']) : '';
    $password = isset($_POST['password']) ? trim($_POST['password']) : '';

    if (isset($_SESSION['login_bloqueo']) && $_SESSION['login_bloqueo'] > time()) {
        $error_message = "Demasiados intentos fallidos. Intenta de nuevo en un momento.";
    } elseif ($email !== '' && $password !== '') {
        $sql = "SELECT u.id_usuario, u.nombre, u.apellido, u.contraseña, r.nombre_rol
                FROM USUARIO u
                INNER JOIN ROL r ON u.id_rol = r.id_rol
                WHERE u.email = ? AND u.estado = 'Activo'
                LIMIT 1";

        $stmt = $conexion->prepare($sql);
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $resultado = $stmt->get_result();
        $usuario = ($resultado && $resultado->num_rows === 1) ? $resultado->fetch_assoc() : null;
        $stmt->close();

        if ($usuario && verificarPassword($password, $usuario['contraseña'])) {

            if (!passwordEsHash($usuario['contraseña']) && columnaPasswordAdmiteHash($conexion)) {
                $nuevo_hash = password_hash($password, PASSWORD_DEFAULT);
                $up = $conexion->prepare("UPDATE USUARIO SET contraseña = ? WHERE id_usuario = ?");
                if ($up) {
                    $up->bind_param("si", $nuevo_hash, $usuario['id_usuario']);
                    $up->execute();
                    $up->close();
                }
            }

            session_regenerate_id(true);
            unset($_SESSION['login_fallos'], $_SESSION['login_bloqueo']);

            $_SESSION['usuario_id'] = $usuario['id_usuario'];
            $_SESSION['usuario_nombre'] = $usuario['nombre'] . " " . $usuario['apellido'];
            $_SESSION['usuario_rol'] = $usuario['nombre_rol'];

            header("Location: " . (esStandard() ? "tickets.php" : "index.php"));
            exit();
        }

        $_SESSION['login_fallos'] = (isset($_SESSION['login_fallos']) ? $_SESSION['login_fallos'] : 0) + 1;
        if ($_SESSION['login_fallos'] >= 5) {
            $_SESSION['login_bloqueo'] = time() + 60;
            $_SESSION['login_fallos'] = 0;
        }
        $error_message = "Credenciales incorrectas.";
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Acceso - TechFlow</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <script src="global.js"></script>
</head>
<body class="login-body">

    <div class="login-card">
        <div style="margin-bottom: 24px;">
            <h2 class="lang" data-es="Ingresar al sistema" data-en="Sign in to platform">Ingresar al sistema</h2>
            <p style="color: var(--text-muted); font-size: 0.8rem; margin-top: 4px;" class="lang" data-es="Introduce tus credenciales de empleado" data-en="Enter your workspace credentials">Introduce tus credenciales de empleado</p>
        </div>

        <?php if (!empty($error_message)): ?>
            <div style="background: #fee2e2; color: #991b1b; padding: 10px; border-radius: 4px; font-size: 0.85rem; margin-bottom: 16px; text-align: center;">
                <?php echo esc($error_message); ?>
            </div>
        <?php endif; ?>

        <form action="login.php" method="POST">
            <div class="form-group">
                <label class="lang" data-es="Correo Corporativo" data-en="Corporate Email">Correo Corporativo</label>
                <input type="email" required autocomplete="username" name="email" placeholder="ejemplo@techflow.com">
            </div>
            <div class="form-group">
                <label class="lang" data-es="Contraseña" data-en="Password">Contraseña</label>
                <input type="password" required autocomplete="current-password" name="password" placeholder="••••••••">
            </div>

            <button type="submit" class="btn-primary" style="width: 100%; justify-content: center; margin-top: 16px;">
                <span class="lang" data-es="Autenticar" data-en="Authenticate">Autenticar</span>
            </button>

            <div style="text-align: center; margin-top: 20px;">
                <span style="font-size: 0.85rem; color: var(--text-muted);">¿Personal nuevo? </span>
                <a href="registro.php" style="color: var(--accent); font-size: 0.85rem; text-decoration: none; font-weight: 600;">Registrate acá</a>
            </div>
        </form>

        <div style="margin-top: 24px; border-top: 1px solid var(--border); padding-top: 16px; text-align: center;">
            <button type="button" id="btn-es" class="lang-btn active">ES</button>
            <button type="button" id="btn-en" class="lang-btn">EN</button>
        </div>
    </div>
</body>
</html>
