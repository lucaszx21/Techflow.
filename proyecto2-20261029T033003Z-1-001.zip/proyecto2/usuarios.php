<?php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/auth.php';
verificarSesion();

if (!esAdmin()) {
    header("Location: tickets.php");
    exit();
}

require_once __DIR__ . '/conexion.php';

$user_name = $_SESSION['usuario_nombre'];
$user_role = $_SESSION['usuario_rol'];

$mapeo_roles = [
    1 => 'Administrador',
    2 => 'Técnico',
    3 => 'Standard'
];

$columna_rol = 'id_rol';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['accion'])) {
    header('Content-Type: application/json; charset=UTF-8');

    if (!csrf_valido()) {
        http_response_code(403);
        echo json_encode(['status' => 'error', 'msg' => 'Sesión inválida. Recarga la página e inténtalo de nuevo.']);
        exit();
    }

    $id_usuario = isset($_POST['id_usuario']) ? intval($_POST['id_usuario']) : 0;
    $id_propio = intval($_SESSION['usuario_id']);

    if ($_POST['accion'] === 'cambiar_rol') {
        $nuevo_rol_texto = isset($_POST['nuevo_rol']) ? $_POST['nuevo_rol'] : '';

        $id_rol_numerico = array_search($nuevo_rol_texto, $mapeo_roles, true);

        if ($id_rol_numerico !== false && $id_usuario === $id_propio && $id_rol_numerico !== 1) {
            echo json_encode(['status' => 'error', 'msg' => 'No puedes quitarte tu propio rol de administrador.']);
            exit();
        }

        if ($id_rol_numerico !== false) {

            $stmt = $conexion->prepare("UPDATE USUARIO SET $columna_rol = ? WHERE id_usuario = ?");
            $stmt->bind_param("ii", $id_rol_numerico, $id_usuario);

            if ($stmt->execute()) {
                                echo json_encode(['status' => 'success', 'msg' => '¡Rol guardado con éxito como (' . $id_rol_numerico . ') en la BD!']);
            } else {
                echo json_encode(['status' => 'error', 'msg' => 'Error al guardar el número de rol en la base de datos.']);
            }
            $stmt->close();
        } else {
            echo json_encode(['status' => 'error', 'msg' => 'Rol inválido.']);
        }
        exit();
    }

    if ($_POST['accion'] === 'eliminar_usuario') {
        if ($id_usuario === 1 || $id_usuario === $id_propio) {
            echo json_encode(['status' => 'error', 'msg' => 'No puedes eliminar a tu propio usuario administrador activo.']);
            exit();
        }

        $stmt = $conexion->prepare("DELETE FROM USUARIO WHERE id_usuario = ?");
        $stmt->bind_param("i", $id_usuario);
        if ($stmt->execute()) {
            echo json_encode(['status' => 'success', 'msg' => 'Usuario eliminado correctamente de la base de datos.']);
        } else {

            $msg = ($conexion->errno === 1451)
                ? 'No se puede eliminar: el usuario tiene registros asociados.'
                : 'No se pudo eliminar el registro.';
            echo json_encode(['status' => 'error', 'msg' => $msg]);
        }
        $stmt->close();
        exit();
    }
}

$sql = "SELECT id_usuario, nombre, apellido, email, $columna_rol AS rol_id_db FROM USUARIO ORDER BY id_usuario ASC";
$resultado_usuarios = $conexion->query($sql);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Gestión de Usuarios - TechFlow</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <script src="global.js"></script>
    <style>

        .usuarios-dark-view input::placeholder {
            color: #64748b !important;
        }
        .role-badge {
            font-size: 0.75rem;
            padding: 4px 10px;
            border-radius: 20px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.02em;
        }
        .role-select {
            padding: 4px 8px;
            border-radius: 6px;
            border: 1px solid #334155 !important;
            background: #0f172a !important;
            color: #ffffff !important;
            font-size: 0.85rem;
            font-weight: 600;
            cursor: pointer;
            display: none;
            outline: none;
        }
        .btn-action {
            background: none;
            border: none;
            cursor: pointer;
            padding: 6px;
            border-radius: 6px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            transition: background 0.2s;
        }
        .btn-action:hover {
            background: #334155;
        }
        .filter-select {
            padding: 8px 12px;
            border-radius: 8px;
            border: 1px solid #334155 !important;
            background: #1e293b !important;
            font-size: 0.9rem;
            color: #ffffff !important;
            cursor: pointer;
            outline: none;
        }
        .tabla-custom tr:hover {
            background: #151f32 !important;
        }
    </style>
</head>
<body style="background-color: #0f172a !important; margin: 0; font-family: system-ui, sans-serif; color: #ffffff !important;" class="usuarios-dark-view">
    <div class="dashboard-container">
        <?php include 'includes/sidebar.php'; ?>

        <main class="main-content" style="height: 100vh; overflow-y: auto;">

            <header class="top-header" style="display: flex; justify-content: flex-end; align-items: center; padding: 15px 30px; background: #1e293b !important; border-bottom: 1px solid #334155 !important; height: 60px; box-sizing: border-box;">
                <?php include 'includes/header.php'; ?>
            </header>

            <div class="content-body" style="padding: 30px; background: #0f172a !important;">
                <section class="data-section" style="background: transparent !important; border: none !important; padding: 0;">

                    <div class="section-header" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px;">
                        <div>
                            <h2 style="color: #ffffff !important; margin: 0; font-size: 1.5rem; font-weight: 600;" class="lang" data-es="Control de Usuarios y Roles" data-en="User & Roles Control">Control de Usuarios y Roles</h2>
                        </div>

                        <div style="display: flex; gap: 12px; align-items: center;">
                            <div style="display: flex; align-items: center; border: 1px solid #334155 !important; border-radius: 8px; padding: 6px 14px; background: #1e293b !important; width: 260px;">
                                <span class="material-icons" style="font-size:18px; color:#94a3b8; margin-right: 8px;">search</span>
                                <input type="text" id="inputBuscar" placeholder="Buscar usuario..." onkeyup="filtrarTabla()" style="background: transparent; border: none; color: #ffffff !important; outline: none; font-size: 0.9rem; width: 100%;">
                            </div>

                            <select id="filtroRol" class="filter-select" onchange="filtrarTabla()">
                                <option value="todos" class="lang" data-es="Todos los Roles" data-en="All Roles" style="background:#1e293b;">Todos los Roles</option>
                                <option value="Administrador" style="background:#1e293b;">Administrador</option>
                                <option value="Técnico" style="background:#1e293b;">Técnico</option>
                                <option value="Standard" style="background:#1e293b;">Standard</option>
                            </select>
                        </div>
                    </div>

                    <div style="background: #1e293b !important; border: 1px solid #334155 !important; border-radius: 12px; padding: 20px; box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.3);">
                        <table style="width: 100%; border-collapse: collapse; text-align: left;" id="tablaUsuarios" class="tabla-custom">
                            <thead>
                                <tr style="border-bottom: 2px solid #334155 !important; color: #94a3b8 !important; font-size: 0.85rem; font-weight: 600; text-transform: uppercase; letter-spacing: 0.03em;">
                                    <th style="padding: 14px 12px;">ID</th>
                                    <th style="padding: 14px 12px;" class="lang" data-es="Nombre" data-en="Name">Nombre</th>
                                    <th style="padding: 14px 12px;" class="lang" data-es="Correo" data-en="Email">Correo</th>
                                    <th style="padding: 14px 12px;" class="lang" data-es="Rol" data-en="Role">Rol</th>
                                    <th style="padding: 14px 12px; text-align: center;" class="lang" data-es="Acciones" data-en="Actions">Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if ($resultado_usuarios && $resultado_usuarios->num_rows > 0): ?>
                                    <?php while($user = $resultado_usuarios->fetch_assoc()): ?>
                                        <?php

                                            $id_del_rol_db = intval($user['rol_id_db']);
                                            $rol_render = isset($mapeo_roles[$id_del_rol_db]) ? $mapeo_roles[$id_del_rol_db] : 'Standard';

                                            $badgeBg = "rgba(148, 163, 184, 0.12)"; $badgeTxt = "#94a3b8";
                                            if ($rol_render === 'Administrador') { $badgeBg = "rgba(239, 68, 68, 0.15)"; $badgeTxt = "#f87171"; }
                                            elseif ($rol_render === 'Técnico') { $badgeBg = "rgba(59, 130, 246, 0.15)"; $badgeTxt = "#60a5fa"; }
                                            elseif ($rol_render === 'Standard') { $badgeBg = "rgba(34, 197, 94, 0.15)"; $badgeTxt = "#4ade80"; }
                                        ?>
                                        <tr style="border-bottom: 1px solid #334155 !important; font-size: 0.9rem; color: #cbd5e1 !important; transition: background 0.2s;" class="fila-usuario" data-rol="<?php echo esc($rol_render); ?>">
                                            <td style="padding: 14px 12px; color: #64748b; font-weight: 500;">#<?php echo intval($user['id_usuario']); ?></td>
                                            <td style="padding: 14px 12px; font-weight: 600; color: #ffffff !important;" class="celda-nombre"><?php echo esc(trim($user['nombre'] . ' ' . $user['apellido'])); ?></td>
                                            <td style="padding: 14px 12px; color: #cbd5e1;"><?php echo esc($user['email']); ?></td>
                                            <td style="padding: 14px 12px;">
                                                <span class="role-badge" id="badge-<?php echo $user['id_usuario']; ?>" style="background: <?php echo $badgeBg; ?> !important; color: <?php echo $badgeTxt; ?> !important;">
                                                    <?php echo $rol_render; ?>
                                                </span>

                                                <select class="role-select" id="select-<?php echo $user['id_usuario']; ?>" onchange="guardarRol(<?php echo $user['id_usuario']; ?>, this.value)">
                                                    <option value="Standard" <?php echo $rol_render == 'Standard' ? 'selected' : ''; ?> style="background:#1e293b;">Standard</option>
                                                    <option value="Técnico" <?php echo $rol_render == 'Técnico' ? 'selected' : ''; ?> style="background:#1e293b;">Técnico</option>
                                                    <option value="Administrador" <?php echo $rol_render == 'Administrador' ? 'selected' : ''; ?> style="background:#1e293b;">Administrador</option>
                                                </select>
                                            </td>
                                            <td style="padding: 14px 12px; text-align: center;">
                                                <button class="btn-action" style="color: #60a5fa; margin-right: 6px;" onclick="habilitarEdicion(<?php echo $user['id_usuario']; ?>)" title="Editar Rol">
                                                    <span class="material-icons" style="font-size: 18px;">edit</span>
                                                </button>
                                                <button class="btn-action" style="color: #f87171;" data-nombre="<?php echo esc(trim($user['nombre'] . ' ' . $user['apellido'])); ?>" onclick="eliminarUsuario(<?php echo intval($user['id_usuario']); ?>, this.dataset.nombre)" title="Eliminar Usuario">
                                                    <span class="material-icons" style="font-size: 18px;">delete</span>
                                                </button>
                                            </td>
                                        </tr>
                                    <?php endwhile; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </section>
            </div>
        </main>
    </div>

    <script>
        const CSRF_TOKEN = <?php echo json_encode(csrf_token()); ?>;

        function filtrarTabla() {
            let busqueda = document.getElementById("inputBuscar").value.toLowerCase();
            let filtroRol = document.getElementById("filtroRol").value;
            let filas = document.getElementsByClassName("fila-usuario");

            for (let i = 0; i < filas.length; i++) {
                let nombre = filas[i].getElementsByClassName("celda-nombre")[0].innerText.toLowerCase();
                let rol = filas[i].getAttribute("data-rol");

                let coincideNombre = nombre.includes(busqueda);
                let coincideRol = (filtroRol === "todos" || rol === filtroRol);

                if (coincideNombre && coincideRol) {
                    filas[i].style.display = "";
                } else {
                    filas[i].style.display = "none";
                }
            }
        }

        function habilitarEdicion(id) {
            let badge = document.getElementById("badge-" + id);
            let select = document.getElementById("select-" + id);
            if(select.style.display === "none" || select.style.display === "") {
                badge.style.display = "none";
                select.style.display = "inline-block";
                select.focus();
            } else {
                badge.style.display = "inline-block";
                select.style.display = "none";
            }
        }

        function guardarRol(id, nuevoRolTexto) {
            let formData = new FormData();
            formData.append('csrf_token', CSRF_TOKEN);
            formData.append('accion', 'cambiar_rol');
            formData.append('id_usuario', id);
            formData.append('nuevo_rol', nuevoRolTexto);

            fetch('usuarios.php', { method: 'POST', body: formData })
            .then(res => res.json())
            .then(data => {
                if(data.status === 'success') {
                    let badge = document.getElementById("badge-" + id);
                    let select = document.getElementById("select-" + id);
                    let fila = select.closest('.fila-usuario');

                    badge.innerText = nuevoRolTexto;
                    fila.setAttribute('data-rol', nuevoRolTexto);

                    if (nuevoRolTexto === 'Administrador') {
                        badge.style.setProperty('background', 'rgba(239, 68, 68, 0.15)', 'important');
                        badge.style.setProperty('color', '#f87171', 'important');
                    } else if (nuevoRolTexto === 'Técnico') {
                        badge.style.setProperty('background', 'rgba(59, 130, 246, 0.15)', 'important');
                        badge.style.setProperty('color', '#60a5fa', 'important');
                    } else {
                        badge.style.setProperty('background', 'rgba(34, 197, 94, 0.15)', 'important');
                        badge.style.setProperty('color', '#4ade80', 'important');
                    }

                    badge.style.display = "inline-block";
                    select.style.display = "none";
                }
                alert(data.msg);
                if (data.status !== 'success') location.reload();
            })
            .catch(() => { alert('Error de conexión con el servidor.'); location.reload(); });
        }

        function eliminarUsuario(id, nombre) {
            if (confirm("¿Estás seguro de que deseas eliminar al usuario '" + nombre + "'?")) {
                let formData = new FormData();
                formData.append('csrf_token', CSRF_TOKEN);
                formData.append('accion', 'eliminar_usuario');
                formData.append('id_usuario', id);

                fetch('usuarios.php', { method: 'POST', body: formData })
                .then(res => res.json())
                .then(data => {
                    if (data.status === 'success') {
                        let select = document.getElementById("select-" + id);
                        select.closest('.fila-usuario').remove();
                    }
                    alert(data.msg);
                })
                .catch(() => alert('Error de conexión con el servidor.'));
            }
        }
    </script>
</body>
</html>
