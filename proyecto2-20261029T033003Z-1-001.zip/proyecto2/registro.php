<?php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once 'conexion.php';
require_once 'auth.php';

$success_message = "";
$error_message = "";

// Quien ya inició sesión como administrador vuelve a "Usuarios y Roles"; el resto, al login.
$url_volver = esAdmin() ? 'usuarios.php' : 'login.php';

// Valores del formulario (se conservan si hay un error)
$v_nombre = '';
$v_apellido = '';
$v_email = '';
$v_rol = 3;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre   = isset($_POST['nombre']) ? trim($_POST['nombre']) : '';
    $apellido = isset($_POST['apellido']) ? trim($_POST['apellido']) : '';
    $email    = isset($_POST['email']) ? trim($_POST['email']) : '';
    $password = isset($_POST['password']) ? trim($_POST['password']) : '';
    $clave_rol = isset($_POST['clave_rol']) ? trim($_POST['clave_rol']) : '';

    $id_rol = isset($_POST['id_rol']) ? intval($_POST['id_rol']) : 3;

    $v_nombre = $nombre;
    $v_apellido = $apellido;
    $v_email = $email;
    $v_rol = in_array($id_rol, [1, 2, 3], true) ? $id_rol : 3;

    if (!csrf_valido()) {
        $error_message = "Sesión inválida. Recarga la página e inténtalo de nuevo.";
    } elseif (!in_array($id_rol, [1, 2, 3], true)) {
        $error_message = "Rol de acceso inválido.";
    } elseif ($nombre === '' || $apellido === '' || $email === '' || $password === '') {
        $error_message = "Por favor, completa todos los campos.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error_message = "El correo electrónico no es válido.";
    } elseif (strlen($password) < 8) {
        $error_message = "La contraseña debe tener al menos 8 caracteres.";
    } elseif (rolRequiereClave($id_rol) && $clave_rol === '') {
        $error_message = "Ingresa la contraseña de autorización para este rol.";
    } elseif (rolRequiereClave($id_rol) && !claveAutorizacionValida($id_rol, $clave_rol)) {
        $error_message = "Contraseña de autorización incorrecta.";
    } else {

        $check_email = $conexion->prepare("SELECT id_usuario FROM USUARIO WHERE email = ?");
        $check_email->bind_param("s", $email);
        $check_email->execute();
        $res = $check_email->get_result();
        $existe = ($res && $res->num_rows > 0);
        $check_email->close();

        if ($existe) {
            $error_message = "El correo ya está registrado por otro empleado.";
        } else {
            $password_guardar = prepararPassword($conexion, $password);

            $sql = "INSERT INTO USUARIO (nombre, apellido, email, contraseña, estado, id_rol) VALUES (?, ?, ?, ?, 'Activo', ?)";
            $stmt = $conexion->prepare($sql);
            $stmt->bind_param("ssssi", $nombre, $apellido, $email, $password_guardar, $id_rol);

            if ($stmt->execute()) {
                $success_message = "¡Personal registrado con éxito! Ya puede iniciar sesión.";
                $v_nombre = $v_apellido = $v_email = '';
                $v_rol = 3;
            } else {
                error_log("TechFlow registro: " . $conexion->error);
                $error_message = "Hubo un error al guardar en la base de datos.";
            }
            $stmt->close();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Registro de Personal - TechFlow</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <script src="global.js"></script>
</head>
<body class="login-body">

    <div class="login-card" style="max-width: 450px;">
        <div style="margin-bottom: 20px;">
            <h2>Registrar Nuevo Personal</h2>
            <p style="color: var(--text-muted); font-size: 0.8rem; margin-top: 4px;">Da de alta una nueva credencial en la base de datos corporativa.</p>
        </div>

        <?php if (!empty($error_message)): ?>
            <div style="background: #fee2e2; color: #991b1b; padding: 10px; border-radius: 4px; font-size: 0.85rem; margin-bottom: 16px; text-align: center;">
                <?php echo esc($error_message); ?>
            </div>
        <?php endif; ?>

        <?php if (!empty($success_message)): ?>
            <div style="background: #dcfce7; color: #166534; padding: 10px; border-radius: 4px; font-size: 0.85rem; margin-bottom: 16px; text-align: center;">
                <?php echo esc($success_message); ?>
            </div>
        <?php endif; ?>

        <form action="registro.php" method="POST" autocomplete="off">
            <?php echo csrf_campo(); ?>
            <div style="display: flex; gap: 10px;">
                <div class="form-group" style="flex: 1;">
                    <label>Nombre</label>
                    <input type="text" required name="nombre" maxlength="60" placeholder="Ej: Carlos" value="<?php echo esc($v_nombre); ?>">
                </div>
                <div class="form-group" style="flex: 1;">
                    <label>Apellido</label>
                    <input type="text" required name="apellido" maxlength="60" placeholder="Ej: Pérez" value="<?php echo esc($v_apellido); ?>">
                </div>
            </div>

            <div class="form-group">
                <label>Correo Corporativo</label>
                <input type="email" required name="email" maxlength="120" placeholder="carlos@techflow.com" value="<?php echo esc($v_email); ?>">
            </div>

            <div class="form-group">
                <label>Contraseña Inicial</label>
                <input type="password" required name="password" minlength="8" autocomplete="new-password" placeholder="••••••••">
            </div>

            <div class="form-group">
                <label>Asignar Rol de Acceso</label>
                <select name="id_rol" id="id_rol" required onchange="actualizarClaveRol()" style="width: 100%; padding: 8px; border: 1px solid var(--border); border-radius: 4px; background: #fff;">
                    <option value="3" <?php echo $v_rol === 3 ? 'selected' : ''; ?>>Standard (Usuario Final)</option>
                    <option value="2" <?php echo $v_rol === 2 ? 'selected' : ''; ?>>Técnico (Soporte TI)</option>
                    <option value="1" <?php echo $v_rol === 1 ? 'selected' : ''; ?>>Administrador (Control Total)</option>
                </select>
            </div>

            <!-- Solo se muestra al elegir Técnico o Administrador -->
            <div class="form-group" id="grupo-clave-rol" style="display: none;">
                <label>Contraseña de autorización</label>
                <input type="password" name="clave_rol" id="clave_rol" autocomplete="new-password" placeholder="Contraseña de autorización del rol">
            </div>

            <button type="submit" class="btn-primary" style="width: 100%; justify-content: center; margin-top: 12px;">
                <span>Dar de Alta Empleado</span>
            </button>
        </form>

        <div style="margin-top: 20px; border-top: 1px solid var(--border); padding-top: 12px; text-align: center;">
            <a href="<?php echo $url_volver; ?>" style="color: var(--accent); font-size: 0.85rem; text-decoration: none; font-weight: 600;">← Volver</a>
        </div>

        <div style="margin-top: 16px; text-align: center;">
            <button type="button" id="btn-es" class="lang-btn active">ES</button>
            <button type="button" id="btn-en" class="lang-btn">EN</button>
        </div>
    </div>

    <script>
        function actualizarClaveRol() {
            var rol = document.getElementById('id_rol').value;
            var grupo = document.getElementById('grupo-clave-rol');
            var input = document.getElementById('clave_rol');
            var requiere = (rol === '1' || rol === '2');

            grupo.style.display = requiere ? 'flex' : 'none';
            input.required = requiere;
            if (!requiere) { input.value = ''; }
        }
        actualizarClaveRol();
    </script>
</body>
</html>
