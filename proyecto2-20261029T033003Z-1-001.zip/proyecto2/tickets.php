<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/auth.php';
verificarSesion();

require_once __DIR__ . '/conexion.php';

$id_usuario = $_SESSION['usuario_id'];
$rol = $_SESSION['usuario_rol'];

if (esStandard()) {
    $sql = "SELECT * FROM TICKET WHERE id_usuario_creador = ? ORDER BY id_ticket DESC";
    $stmt = $conexion->prepare($sql);
    $stmt->bind_param("i", $id_usuario);
    $stmt->execute();
    $resultado = $stmt->get_result();
} else {
    $sql = "SELECT * FROM TICKET ORDER BY id_ticket DESC";
    $resultado = $conexion->query($sql);
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Mesa de Soporte - TechFlow</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <script src="global.js"></script>

    <style>

        .soporte-dark-view input::placeholder,
        .soporte-dark-view textarea::placeholder {
            color: #64748b !important;
        }
        .ticket-click-card:hover {
            background: #1e293b !important;
            border-color: #475569 !important;
            transform: translateX(4px);
        }
        .ticket-click-card {
            transition: all 0.2s ease-in-out;
        }
    </style>
</head>
<body style="background-color: #0f172a !important; margin: 0; font-family: system-ui, sans-serif; color: #ffffff !important;" class="soporte-dark-view">
    <div class="dashboard-container">
        <?php include 'includes/sidebar.php'; ?>

        <main class="main-content" style="height: 100vh; overflow-y: auto;">
            <header class="top-header" style="display: flex; justify-content: space-between; align-items: center; padding: 15px 30px; background: #1e293b !important; border-bottom: 1px solid #334155 !important; height: 60px;">
                <div class="search-bar-container" style="display: flex; align-items: center; background: #0f172a !important; border: 1px solid #334155 !important; border-radius: 8px; padding: 6px 12px; width: 340px;">
                    <span class="material-icons" style="font-size:18px; color:#94a3b8; margin-right: 8px;">search</span>
                    <input type="text" id="ticket-search" placeholder="Buscar en el sistema..." style="background: transparent; border: none; color: #ffffff !important; outline: none; width: 100%; font-size: 0.85rem;">
                </div>
                <?php include 'includes/header.php'; ?>
            </header>

            <div class="content-body" style="padding: 30px; background: #0f172a !important; min-height: calc(100vh - 60px);">
                <section class="data-section" style="background: transparent !important; border: none !important; padding: 0;">

                    <?php
                    $errores_tickets = [
                        'sesion'  => 'Sesión inválida. Recarga la página e inténtalo de nuevo.',
                        'vacios'  => 'Completa el título y la descripción.',
                        'db'      => 'Error al guardar el ticket.'
                    ];
                    if (isset($_GET['success'])): ?>
                        <div class="alert-ok">Ticket creado correctamente.</div>
                    <?php elseif (isset($_GET['error']) && isset($errores_tickets[$_GET['error']])): ?>
                        <div class="alert-err"><?php echo esc($errores_tickets[$_GET['error']]); ?></div>
                    <?php endif; ?>

                    <div class="section-header" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px;">
                        <div>
                            <h2 style="color: #ffffff !important; margin: 0; font-size: 1.5rem; font-weight: 600;">Mis Incidentes (Mesa de Entrada)</h2>
                        </div>
                        <button class="btn-primary" onclick="openModal()" style="display: flex; align-items: center; gap: 8px; background: #3b82f6 !important; color: white !important; border: none !important; padding: 10px 16px; border-radius: 8px; font-weight: 600; cursor: pointer; transition: background 0.2s;">
                            <span class="material-icons" style="font-size:18px">add</span>
                            <span>Nuevo Ticket</span>
                        </button>
                    </div>

                    <div style="display: flex; gap: 24px; align-items: flex-start;">

                        <div style="flex: 1.2; background: #1e293b !important; border: 1px solid #334155 !important; border-radius: 12px; padding: 20px; box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.3);">
                            <?php if ($resultado && $resultado->num_rows > 0): ?>
                                <?php while($ticket = $resultado->fetch_assoc()): ?>

                                    <div class="ticket-click-card" data-busqueda="<?php echo esc(strtolower('#' . $ticket['id_ticket'] . ' ' . $ticket['titulo'] . ' ' . $ticket['descripcion'])); ?>"
                                         style="padding: 14px; border: 1px solid #334155 !important; cursor: pointer; background: #151f32 !important; margin-bottom: 10px; border-radius: 8px;"
                                         onclick="cargarSeguimiento(<?php echo intval($ticket['id_ticket']); ?>)">

                                        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px;">
                                            <strong style="color: #ffffff !important; font-size: 0.95rem; font-weight: 600;">
                                                <?php echo esc($ticket['titulo']); ?>
                                            </strong>

                                            <?php
                                            $estadoTick = strtolower($ticket['estado']);
                                            $eBg = "rgba(148, 163, 184, 0.15)"; $eTxt = "#94a3b8";
                                            if ($estadoTick === 'abierto') { $eBg = "rgba(59, 130, 246, 0.15)"; $eTxt = "#60a5fa"; }
                                            elseif ($estadoTick === 'cerrado') { $eBg = "rgba(34, 197, 94, 0.15)"; $eTxt = "#4ade80"; }
                                            ?>
                                            <span style="font-size: 0.72rem; background: <?php echo $eBg; ?> !important; color: <?php echo $eTxt; ?> !important; padding: 3px 8px; border-radius: 20px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.02em;">
                                                <?php echo esc($ticket['estado']); ?>
                                            </span>
                                        </div>

                                        <p style="font-size: 0.85rem; color: #cbd5e1 !important; margin: 4px 0 10px 0; line-height: 1.4;"><?php echo esc($ticket['descripcion']); ?></p>

                                        <div style="display: flex; align-items: center; gap: 4px; color: #94a3b8 !important; font-size: 0.75rem;">
                                            <span class="material-icons" style="font-size: 14px; color: #64748b;">priority_high</span>
                                            <span>Prioridad: <strong style="color: #e2e8f0; font-weight: 500;"><?php echo esc($ticket['prioridad']); ?></strong></span>
                                        </div>
                                    </div>

                                <?php endwhile; ?>
                            <?php else: ?>
                                <div style="text-align: center; padding: 40px 20px; color: #94a3b8 !important;">
                                    <span class="material-icons" style="font-size: 40px; color: #334155; margin-bottom: 10px;">assignment_late</span>
                                    <p style="margin: 0; font-size: 0.88rem;">Ningún ticket creado actualmente en tu cuenta.</p>
                                </div>
                            <?php endif; ?>
                        </div>

                        <div style="flex: 1; background: #1e293b !important; border: 1px solid #334155 !important; border-radius: 12px; padding: 24px; box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.3); position: sticky; top: 84px;" id="panel-seguimiento">
                            <h3 style="margin: 0 0 12px 0; color: #ffffff !important; font-size: 1.15rem; font-weight: 600; display: flex; align-items: center; gap: 8px;">
                                <span class="material-icons" style="color: #3b82f6; font-size: 20px;">history</span>
                                <span>Estado y Evolución</span>
                            </h3>
                            <p style="color: #94a3b8 !important; font-size: 0.85rem; line-height: 1.5; padding: 12px; background: #151f32 !important; border-radius: 8px; border: 1px dashed #334155; margin: 0;">
                                Selecciona un incidente del panel de la izquierda para desplegar la trazabilidad interna y las respuestas del cuerpo de soporte técnico.
                            </p>
                        </div>
                    </div>
                </section>
            </div>
        </main>
    </div>

    <div id="modal-ticket" style="display:none; position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(15, 23, 42, 0.75); z-index:1000; align-items:center; justify-content:center; backdrop-filter: blur(4px);">
        <div style="background: #1e293b !important; border: 1px solid #334155 !important; padding: 28px; border-radius: 12px; width: 440px; box-shadow: 0 20px 25px -5px rgba(0,0,0,0.5); color: #ffffff !important;">
            <h3 style="margin-top:0; margin-bottom:20px; color: #ffffff !important; font-size: 1.25rem; font-weight: 600;">Abrir Nuevo Ticket de Soporte</h3>

            <form action="guardar_ticket.php" method="POST" style="margin-top:14px;">
                <?php echo csrf_campo(); ?>
                <div class="form-group" style="margin-bottom:14px; display: flex; flex-direction: column; gap: 6px;">
                    <label style="font-size:0.82rem; font-weight:600; color: #94a3b8 !important;">Título del Incidente*</label>
                    <input type="text" name="titulo" required maxlength="150" placeholder="Ej: No conecta a la VPN de la empresa" style="width:100%; padding:10px; background: #0f172a !important; border:1px solid #334155 !important; border-radius:6px; color:#ffffff !important; box-sizing: border-box; outline:none; font-size:0.9rem;">
                </div>

                <div class="form-group" style="margin-bottom:14px; display: flex; flex-direction: column; gap: 6px;">
                    <label style="font-size:0.82rem; font-weight:600; color: #94a3b8 !important;">Descripción detallada de la falla*</label>
                    <textarea name="descripcion" required rows="4" maxlength="5000" style="width:100%; border:1px solid #334155 !important; background: #0f172a !important; border-radius:6px; padding:10px; color:#ffffff !important; box-sizing: border-box; outline:none; font-size:0.9rem; resize: none;" placeholder="Aporta detalles del error o comportamiento extraño..."></textarea>
                </div>

                <div class="form-group" style="margin-bottom:24px; display: flex; flex-direction: column; gap: 6px;">
                    <label style="font-size:0.82rem; font-weight:600; color: #94a3b8 !important;">Prioridad Estándar</label>
                    <select name="prioridad" style="width:100%; padding:10px; border:1px solid #334155 !important; background: #0f172a !important; color:#ffffff !important; border-radius:6px; box-sizing: border-box; outline:none; cursor:pointer; font-size:0.9rem;">
                        <option value="Baja" style="background:#1e293b; color:#ffffff;">Baja</option>
                        <option value="Media" selected style="background:#1e293b; color:#ffffff;">Media</option>
                        <option value="Alta" style="background:#1e293b; color:#ffffff;">Alta</option>
                    </select>
                </div>

                <div style="display:flex; gap:10px; justify-content:flex-end;">
                    <button type="button" onclick="closeModal()" style="padding:10px 18px; background:#334155; border:none; border-radius:8px; cursor:pointer; font-weight:600; color:#e2e8f0; transition: background 0.2s;">Cancelar</button>
                    <button type="submit" class="btn-primary" style="background: #3b82f6 !important; color: white !important; border: none !important; padding: 10px 18px; border-radius: 8px; font-weight: 600; cursor: pointer;">Enviar Ticket</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        function openModal() { document.getElementById('modal-ticket').style.display='flex'; }
        function closeModal() { document.getElementById('modal-ticket').style.display='none'; }

        document.addEventListener('keydown', e => { if (e.key === 'Escape') closeModal(); });
        document.getElementById('modal-ticket').addEventListener('click', e => { if (e.target.id === 'modal-ticket') closeModal(); });

        document.getElementById('ticket-search').addEventListener('input', function () {
            const q = this.value.toLowerCase().trim();
            document.querySelectorAll('.ticket-click-card').forEach(card => {
                card.style.display = card.dataset.busqueda.includes(q) ? '' : 'none';
            });
        });

        function cargarSeguimiento(id) {
            document.getElementById('panel-seguimiento').innerHTML = `
                <div style="display: flex; align-items: center; gap: 8px; color: #94a3b8;">
                    <span class="material-icons" style="animation: spin 1s linear infinite;">sync</span>
                    <p style="margin:0; font-size:0.88rem;">Sincronizando trazabilidad técnica...</p>
                </div>
            `;
            fetch('obtener_seguimiento.php?id=' + id, { credentials: 'same-origin' })
                .then(response => {
                    if (!response.ok) throw new Error('http ' + response.status);
                    return response.text();
                })
                .then(data => {
                    document.getElementById('panel-seguimiento').innerHTML = data;
                })
                .catch(() => {
                    document.getElementById('panel-seguimiento').textContent = 'No se pudo cargar el seguimiento.';
                });
        }
    </script>
</body>
</html>
