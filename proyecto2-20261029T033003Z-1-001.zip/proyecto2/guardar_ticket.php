<?php

if (session_status() === PHP_SESSION_NONE) { session_start(); }
require_once 'conexion.php';
require_once 'auth.php';
verificarSesion();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: tickets.php");
    exit();
}

if (!csrf_valido()) {
    header("Location: tickets.php?error=sesion");
    exit();
}

$titulo = isset($_POST['titulo']) ? trim($_POST['titulo']) : '';
$descripcion = isset($_POST['descripcion']) ? trim($_POST['descripcion']) : '';
$prioridad = isset($_POST['prioridad']) ? trim($_POST['prioridad']) : 'Media';
$id_usuario_creador = intval($_SESSION['usuario_id']);

if (!in_array($prioridad, ['Baja', 'Media', 'Alta'], true)) {
    $prioridad = 'Media';
}

if ($titulo === '' || $descripcion === '') {
    header("Location: tickets.php?error=vacios");
    exit();
}

$titulo = mb_substr($titulo, 0, 150);
$descripcion = mb_substr($descripcion, 0, 5000);

$sql = "INSERT INTO TICKET (titulo, descripcion, prioridad, estado, id_usuario_creador) VALUES (?, ?, ?, 'Abierto', ?)";
$stmt = $conexion->prepare($sql);
$stmt->bind_param("sssi", $titulo, $descripcion, $prioridad, $id_usuario_creador);

if ($stmt->execute()) {
    header("Location: tickets.php?success=1");
} else {
    error_log("TechFlow guardar_ticket: " . $conexion->error);
    header("Location: tickets.php?error=db");
}
$stmt->close();
exit();
?>
