<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once 'auth.php';
verificarSesion();

require_once 'conexion.php';

if (!esTecnico() && !esAdmin()) {
    header("Location: tickets.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id_ticket'])) {
    if (!csrf_valido()) {
        header("Location: caja_tickets.php?error=sesion");
        exit();
    }

    $id_ticket = intval($_POST['id_ticket']);
    $diagnostico = isset($_POST['diagnostico']) ? trim($_POST['diagnostico']) : '';
    $solucion = isset($_POST['solucion']) ? trim($_POST['solucion']) : '';
    $id_tecnico = intval($_SESSION['usuario_id']);

    if ($id_ticket > 0 && $diagnostico !== '' && $solucion !== '') {

        $conexion->begin_transaction();
        $ok = false;

        $stmt2 = $conexion->prepare("UPDATE TICKET SET estado = 'Cerrado', fecha_cierre = NOW(), id_tecnico_asignado = ? WHERE id_ticket = ? AND estado = 'Abierto'");
        $stmt2->bind_param("ii", $id_tecnico, $id_ticket);
        $stmt2->execute();
        $cerrado = ($stmt2->affected_rows === 1);
        $stmt2->close();

        if ($cerrado) {
            $stmt = $conexion->prepare("INSERT INTO DIAGNOSTICO (id_ticket, id_tecnico, diagnostico, solucion) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("iiss", $id_ticket, $id_tecnico, $diagnostico, $solucion);
            $ok = $stmt->execute();
            $stmt->close();
        }

        if ($ok) {
            $conexion->commit();
            header("Location: caja_tickets.php?success=1");
        } else {
            $conexion->rollback();
            header("Location: caja_tickets.php?error=" . ($cerrado ? "db" : "cerrado"));
        }
        exit();
    }
    header("Location: caja_tickets.php?error=vacios");
    exit();
}

$sql = "SELECT t.*, u.nombre, u.apellido FROM TICKET t
        INNER JOIN USUARIO u ON t.id_usuario_creador = u.id_usuario
        WHERE t.estado = 'Abierto' ORDER BY t.id_ticket ASC";
$resultado = $conexion->query($sql);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Caja de Tickets - TechFlow</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <script src="global.js"></script>

    <style>

        .tickets-dark-view input::placeholder,
        .tickets-dark-view textarea::placeholder {
            color: #64748b !important;
        }
        .ticket-item-card:hover {
            background: #1e293b !important;
            border-color: #475569 !important;
            transform: translateY(-2px);
        }
        .ticket-item-card {
            transition: all 0.2s ease-in-out;
        }
    </style>
</head>
<body style="background-color: #0f172a !important; margin: 0; font-family: system-ui, sans-serif; color: #ffffff !important;" class="tickets-dark-view">
    <div class="dashboard-container">
        <?php include 'includes/sidebar.php'; ?>

        <main class="main-content" style="height: 100vh; overflow-y: auto; display: flex; flex-direction: column;">

            <header class="top-header" style="display: flex; justify-content: space-between; align-items: center; padding: 15px 30px; background: #1e293b !important; border-bottom: 1px solid #334155 !important; height: 60px; min-height: 60px;">
                <div class="search-bar-container" style="display: flex; align-items: center; background: #0f172a !important; border: 1px solid #334155 !important; border-radius: 8px; padding: 6px 12px; width: 340px;">
                    <span class="material-icons" style="font-size:18px; color:#94a3b8; margin-right: 8px;">search</span>
                    <input type="text" id="ticket-search" placeholder="Buscar en la fila por código o título..." style="background: transparent; border: none; color: #ffffff !important; outline: none; width: 100%; font-size: 0.85rem;">
                </div>
                <?php include 'includes/header.php'; ?>
            </header>

            <div class="content-body" style="padding: 30px; background: #0f172a !important; flex-grow: 1;">

                <?php if (isset($_GET['success'])): ?>
                    <div style="background: rgba(34, 197, 94, 0.15); border: 1px solid #22c55e; color: #4ade80; padding: 12px 16px; border-radius: 8px; font-size: 0.9rem; margin-bottom: 20px; display: flex; align-items: center; gap: 8px;">
                        <span class="material-icons" style="font-size: 18px;">check_circle</span>
                        <span>¡Incidencia resuelta con éxito! El diagnóstico fue guardado y el ticket se ha cerrado correctamente.</span>
                    </div>
                <?php endif; ?>

                <?php
                $errores_caja = [
                    'sesion'  => 'Sesión inválida. Recarga la página e inténtalo de nuevo.',
                    'vacios'  => 'Por favor, completa todos los campos.',
                    'cerrado' => 'Este ticket ya fue resuelto por otro técnico.',
                    'db'      => 'Hubo un error al guardar en la base de datos.'
                ];
                if (isset($_GET['error']) && isset($errores_caja[$_GET['error']])): ?>
                    <div style="background: rgba(239, 68, 68, 0.15); border: 1px solid #ef4444; color: #f87171; padding: 12px 16px; border-radius: 8px; font-size: 0.9rem; margin-bottom: 20px;">
                        <?php echo esc($errores_caja[$_GET['error']]); ?>
                    </div>
                <?php endif; ?>

                <div style="display: flex; gap: 24px; align-items: flex-start;">

                    <div style="flex: 1.4;">
                        <h2 style="color: #ffffff !important; margin: 0 0 6px 0; font-size: 1.4rem; font-weight: 600;">Bandeja de Tickets Globales</h2>
                        <p style="color: #94a3b8 !important; font-size:0.85rem; margin: 0 0 20px 0;">Interactúa y soluciona los requerimientos técnicos de la infraestructura corporativa.</p>

                        <div style="background: #1e293b !important; border: 1px solid #334155 !important; border-radius: 12px; padding: 20px; box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.3);">
                            <?php if ($resultado && $resultado->num_rows > 0): ?>
                                <?php while($t = $resultado->fetch_assoc()): ?>

                                    <div class="ticket-item-card"
                                         style="padding: 16px; border: 1px solid #334155 !important; border-radius: 8px; margin-bottom: 12px; cursor: pointer; background: #151f32 !important;"
                                         data-id="<?php echo intval($t['id_ticket']); ?>" data-titulo="<?php echo esc($t['titulo']); ?>" data-usuario="<?php echo esc($t['nombre'].' '.$t['apellido']); ?>">

                                        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
                                            <span style="font-size: 0.95rem; font-weight: 600; color: #ffffff !important; display: flex; align-items: center; gap: 6px;">
                                                <span style="color: #3b82f6;">#<?php echo $t['id_ticket']; ?></span> — <?php echo esc($t['titulo']); ?>
                                            </span>

                                            <?php
                                            $pri = strtolower($t['prioridad']);
                                            $pBg = "rgba(148, 163, 184, 0.12)"; $pTxt = "#94a3b8";
                                            if ($pri === 'alta' || $pri === 'critica' || $pri === 'crítica') { $pBg = "rgba(239, 68, 68, 0.15)"; $pTxt = "#f87171"; }
                                            elseif ($pri === 'media') { $pBg = "rgba(234, 179, 8, 0.15)"; $pTxt = "#facc15"; }
                                            elseif ($pri === 'baja') { $pBg = "rgba(34, 197, 94, 0.15)"; $pTxt = "#4ade80"; }
                                            ?>
                                            <span style="background: <?php echo $pBg; ?> !important; color: <?php echo $pTxt; ?> !important; padding: 4px 10px; border-radius: 20px; font-size: 0.75rem; font-weight: 600; text-transform: uppercase; letter-spacing: 0.02em;">
                                                <?php echo esc($t['prioridad']); ?>
                                            </span>
                                        </div>

                                        <p style="font-size: 0.88rem; line-height: 1.4; margin: 0 0 12px 0; color: #cbd5e1 !important;"><?php echo esc($t['descripcion']); ?></p>

                                        <div style="display: flex; align-items: center; gap: 4px; color: #94a3b8 !important; font-size: 0.78rem;">
                                            <span class="material-icons" style="font-size: 14px; color: #64748b;">person</span>
                                            <span>Solicitado por: <strong style="color: #e2e8f0; font-weight: 500;"><?php echo esc($t['nombre'].' '.$t['apellido']); ?></strong></span>
                                        </div>
                                    </div>

                                <?php endwhile; ?>
                            <?php else: ?>
                                <div style="text-align: center; padding: 40px 20px; color: #94a3b8 !important;">
                                    <span class="material-icons" style="font-size: 44px; color: #334155; margin-bottom: 10px;">assignment_turned_in</span>
                                    <h4 style="margin: 0; color: #e2e8f0; font-weight: 500; font-size: 1rem;">Fila de operaciones limpia</h4>
                                    <p style="margin: 4px 0 0 0; font-size: 0.8rem; color: #64748b;">No hay tickets pendientes por resolver en este momento. 🎉</p>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div style="flex: 1; background: #1e293b !important; border: 1px solid #334155 !important; border-radius: 12px; padding: 24px; box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.3); position: sticky; top: 84px;">
                        <h3 style="color: #ffffff !important; margin: 0 0 4px 0; font-size: 1.15rem; font-weight: 600; display: flex; align-items: center; gap: 8px;">
                            <span class="material-icons" style="color: #3b82f6; font-size: 20px;">build</span>
                            <span>Resolución de Incidencia</span>
                        </h3>

                        <div id="ticket-info-resolucion" style="margin: 14px 0; color: #94a3b8 !important; font-size: 0.85rem; line-height: 1.4; padding: 12px; background: #151f32 !important; border-radius: 8px; border: 1px dashed #334155;">
                            Selecciona un ticket entrante de la fila izquierda para aplicar los parámetros de ingeniería.
                        </div>

                        <form action="caja_tickets.php" method="POST" id="form-resolver" style="display: none; margin-top: 16px;">
                            <?php echo csrf_campo(); ?>
                            <input type="hidden" name="id_ticket" id="input-id-ticket">

                            <div class="form-group" style="margin-bottom: 14px; display: flex; flex-direction: column; gap: 6px;">
                                <label style="font-size: 0.8rem; font-weight: 600; color: #94a3b8 !important;">Diagnóstico Técnico Oficial</label>
                                <textarea name="diagnostico" required rows="3"
                                          style="width: 100%; border: 1px solid #334155 !important; background: #0f172a !important; color: #ffffff !important; padding: 10px; border-radius: 6px; outline: none; font-size: 0.88rem; box-sizing: border-box; resize: vertical;"
                                          placeholder="Describe la evaluación de la falla o anomalía encontrada..."></textarea>
                            </div>

                            <div class="form-group" style="margin-bottom: 20px; display: flex; flex-direction: column; gap: 6px;">
                                <label style="font-size: 0.8rem; font-weight: 600; color: #94a3b8 !important;">Mitigación / Acción de Cierre</label>
                                <textarea name="solucion" required rows="3"
                                          style="width: 100%; border: 1px solid #334155 !important; background: #0f172a !important; color: #ffffff !important; padding: 10px; border-radius: 6px; outline: none; font-size: 0.88rem; box-sizing: border-box; resize: vertical;"
                                          placeholder="Escribe los procedimientos correctivos o la solución de ingeniería aplicada..."></textarea>
                            </div>

                            <button type="submit" class="btn-primary"
                                    style="width: 100%; justify-content: center; background: #22c55e !important; color: #ffffff !important; border: none !important; padding: 12px; border-radius: 8px; font-weight: 600; font-size: 0.9rem; cursor: pointer; display: flex; align-items: center; gap: 8px; transition: background 0.2s;">
                                <span class="material-icons" style="font-size: 18px;">bolt</span>
                                <span>Almacenar y Solucionar Caso</span>
                            </button>
                        </form>
                    </div>

                </div>
            </div>
        </main>
    </div>

    <script>

        function seleccionarTicket(id, titulo, usuario) {
            document.getElementById('input-id-ticket').value = id;

            const infoBox = document.getElementById('ticket-info-resolucion');
            infoBox.style.background = "rgba(59, 130, 246, 0.1)";
            infoBox.style.border = "1px solid #3b82f6";
            infoBox.textContent = '';

            const l1 = document.createElement('div');
            l1.style.cssText = 'font-size:0.8rem;text-transform:uppercase;color:#3b82f6;font-weight:700;margin-bottom:4px;letter-spacing:0.02em;';
            l1.textContent = 'Caso en Gestión';

            const l2 = document.createElement('div');
            l2.style.cssText = 'color:#ffffff;font-weight:600;font-size:0.9rem;margin-bottom:2px;';
            l2.textContent = '#' + id + ' — ' + titulo;

            const l3 = document.createElement('div');
            l3.style.cssText = 'color:#94a3b8;font-size:0.78rem;';
            l3.textContent = 'Usuario: ' + usuario;

            infoBox.append(l1, l2, l3);
            document.getElementById('form-resolver').style.display = 'block';
        }

        document.querySelectorAll('.ticket-item-card').forEach(card => {
            card.addEventListener('click', () => {
                seleccionarTicket(card.dataset.id, card.dataset.titulo, card.dataset.usuario);
            });
        });

        document.getElementById('ticket-search').addEventListener('input', function () {
            const q = this.value.toLowerCase().trim();
            document.querySelectorAll('.ticket-item-card').forEach(card => {
                const texto = ('#' + card.dataset.id + ' ' + card.dataset.titulo + ' ' + card.dataset.usuario).toLowerCase();
                card.style.display = texto.includes(q) ? '' : 'none';
            });
        });
    </script>
</body>
</html>
