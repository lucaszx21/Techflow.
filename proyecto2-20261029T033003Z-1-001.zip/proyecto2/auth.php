<?php

if (session_status() === PHP_SESSION_NONE) {
    ini_set('session.cookie_httponly', '1');
    ini_set('session.use_strict_mode', '1');
    session_start();
}

function esc($valor) {
    return htmlspecialchars((string)$valor, ENT_QUOTES, 'UTF-8');
}

function verificarSesion() {
    if (!isset($_SESSION['usuario_id']) || !isset($_SESSION['usuario_nombre']) || !isset($_SESSION['usuario_rol'])) {
        header("Location: login.php");
        exit();
    }
}

$user_name = isset($_SESSION['usuario_nombre']) ? $_SESSION['usuario_nombre'] : 'Invitado';
$user_role = isset($_SESSION['usuario_rol']) ? $_SESSION['usuario_rol'] : 'Invitado';

function esAdmin() {
    return (isset($_SESSION['usuario_rol']) && ($_SESSION['usuario_rol'] === 'Administrador' || $_SESSION['usuario_rol'] === 'admin'));
}

function esTecnico() {
    return (isset($_SESSION['usuario_rol']) && ($_SESSION['usuario_rol'] === 'Técnico' || $_SESSION['usuario_rol'] === 'Tecnico'));
}

function esStandard() {
    return (isset($_SESSION['usuario_rol']) && ($_SESSION['usuario_rol'] === 'Standard' || $_SESSION['usuario_rol'] === 'user'));
}

// Contraseñas de autorización para registrarse con un rol privilegiado.
// (Para cambiarlas, edita únicamente estas líneas.)
// El id de rol coincide con la tabla ROL: 1 = Administrador, 2 = Técnico, 3 = Standard.
function clavesAutorizacionRol($id_rol) {
    $claves = [
        1 => ['administrado123', 'administrador123'],
        2 => ['tecnico123'],
    ];
    return isset($claves[$id_rol]) ? $claves[$id_rol] : [];
}

function rolRequiereClave($id_rol) {
    return count(clavesAutorizacionRol($id_rol)) > 0;
}

function claveAutorizacionValida($id_rol, $clave_ingresada) {
    foreach (clavesAutorizacionRol($id_rol) as $clave) {
        if (hash_equals($clave, (string)$clave_ingresada)) {
            return true;
        }
    }
    return false;
}

function csrf_token() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function csrf_campo() {
    return '<input type="hidden" name="csrf_token" value="' . esc(csrf_token()) . '">';
}

function csrf_valido() {
    $enviado = isset($_POST['csrf_token']) ? $_POST['csrf_token'] : '';
    return is_string($enviado) && !empty($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $enviado);
}

function columnaPasswordAdmiteHash($conexion) {
    static $resultado = null;
    if ($resultado !== null) return $resultado;
    $resultado = false;
    $q = $conexion->query("SELECT CHARACTER_MAXIMUM_LENGTH AS largo FROM information_schema.COLUMNS
                           WHERE TABLE_SCHEMA = DATABASE() AND LOWER(TABLE_NAME) = 'usuario'
                           AND COLUMN_NAME = 'contraseña' LIMIT 1");
    if ($q && ($fila = $q->fetch_assoc())) {
        $resultado = ($fila['largo'] === null || intval($fila['largo']) >= 60);
    }
    return $resultado;
}

function prepararPassword($conexion, $plano) {
    if (columnaPasswordAdmiteHash($conexion)) {
        return password_hash($plano, PASSWORD_DEFAULT);
    }

    return $plano;
}

function passwordEsHash($guardada) {
    return (bool)preg_match('/^\$(2[aby]|argon2id?)\$/', (string)$guardada);
}

function verificarPassword($plano, $guardada) {
    if (passwordEsHash($guardada)) {
        return password_verify($plano, $guardada);
    }
    return hash_equals((string)$guardada, (string)$plano);
}
?>
