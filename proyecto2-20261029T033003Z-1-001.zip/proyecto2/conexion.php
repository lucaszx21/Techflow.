<?php

$host = "localhost";
$user = "root";
$password = "";
$database = "techflow_db";

mysqli_report(MYSQLI_REPORT_OFF);

$conexion = @new mysqli($host, $user, $password, $database);

if ($conexion->connect_error) {
    error_log("TechFlow - error de conexión: " . $conexion->connect_error);
    http_response_code(500);
    die("No se pudo conectar con la base de datos. Inténtalo más tarde.");
}
$conexion->set_charset("utf8mb4");
?>
