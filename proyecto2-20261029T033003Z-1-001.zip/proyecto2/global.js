(function () {
    'use strict';
    if (window.i18n) return;

    const DICT = {

        'Dashboard': 'Dashboard',
        'Panel': 'Dashboard',
        'Panel de Control': 'Control Panel',
        'Inicio': 'Home',
        'Tickets': 'Tickets',
        'Mis Tickets': 'My Tickets',
        'Mesa de Soporte': 'Support Desk',
        'Mesa de Entrada': 'Inbox',
        'Caja de Tickets': 'Ticket Box',
        'Bandeja Global': 'Global Inbox',
        'Inventario': 'Inventory',
        'Inventario TI': 'IT Inventory',
        'Equipos': 'Equipment',
        'Usuarios': 'Users',
        'Gestión de Usuarios': 'User Management',
        'Configuración': 'Settings',
        'Soporte': 'Support',
        'Cerrar Sesión': 'Log out',
        'Cerrar sesión': 'Log out',
        'Salir': 'Log out',
        'Invitado': 'Guest',
        'Rol:': 'Role:',

        'Acceso - TechFlow': 'Sign in - TechFlow',
        'Ingresar al sistema': 'Sign in to platform',
        'Introduce tus credenciales de empleado': 'Enter your workspace credentials',
        'Correo Corporativo': 'Corporate Email',
        'Contraseña': 'Password',
        'Autenticar': 'Authenticate',
        '¿Personal nuevo?': 'New staff?',
        'Registrate acá': 'Register here',
        'Contraseña incorrecta.': 'Incorrect password.',
        'El correo electrónico no está registrado.': 'This email address is not registered.',

        'Registro de Personal - TechFlow': 'Staff Registration - TechFlow',
        'Registrar Nuevo Personal': 'Register New Staff',
        'Da de alta una nueva credencial en la base de datos corporativa.': 'Add a new credential to the corporate database.',
        'El correo ya está registrado por otro empleado.': 'This email is already registered by another employee.',
        '¡Personal registrado con éxito! Ya puede iniciar sesión.': 'Staff member registered successfully! They can now sign in.',
        'Por favor, completa todos los campos.': 'Please fill in all fields.',
        'Nombre': 'Name',
        'Apellido': 'Last name',
        'Contraseña Inicial': 'Initial Password',
        'Asignar Rol de Acceso': 'Assign Access Role',
        'Standard (Usuario Final)': 'Standard (End User)',
        'Técnico (Soporte TI)': 'Technician (IT Support)',
        'Administrador (Control Total)': 'Administrator (Full Control)',
        'Dar de Alta Empleado': 'Register Employee',
        '← Volver al Login': '← Back to Login',
        'Ej: Carlos': 'e.g. Carlos',
        'Ej: Pérez': 'e.g. Smith',

        'Dashboard TI - TechFlow': 'IT Dashboard - TechFlow',
        'Tickets Totales': 'Total Tickets',
        'Tickets Cerrados': 'Closed Tickets',
        'Equipos Inventario': 'Inventory Equipment',
        'Eficiencia de Tickets': 'Ticket Efficiency',
        'Volúmenes del Sistema': 'System Volumes',
        'Pendientes': 'Pending',
        'Resueltos': 'Resolved',
        'Cantidad Registrada': 'Registered Amount',
        'Equipos TI': 'IT Equipment',
        'Total Tickets': 'Total Tickets',

        'Mesa de Soporte - TechFlow': 'Support Desk - TechFlow',
        'Buscar en el sistema...': 'Search the system...',
        'Mis Incidentes (Mesa de Entrada)': 'My Incidents (Inbox)',
        'Nuevo Ticket': 'New Ticket',
        'Ningún ticket creado actualmente en tu cuenta.': 'No tickets currently created in your account.',
        'Prioridad:': 'Priority:',
        'Estado y Evolución': 'Status and Progress',
        'Selecciona un incidente del panel de la izquierda para desplegar la trazabilidad interna y las respuestas del cuerpo de soporte técnico.':
            'Select an incident from the left panel to view the internal traceability and the technical support team\'s responses.',
        'Abrir Nuevo Ticket de Soporte': 'Open New Support Ticket',
        'Título del Incidente*': 'Incident Title*',
        'Ej: No conecta a la VPN de la empresa': 'e.g. Cannot connect to the company VPN',
        'Descripción detallada de la falla*': 'Detailed description of the issue*',
        'Aporta detalles del error o comportamiento extraño...': 'Provide details about the error or unusual behavior...',
        'Prioridad Estándar': 'Standard Priority',
        'Baja': 'Low',
        'Media': 'Medium',
        'Alta': 'High',
        'Crítica': 'Critical',
        'Critica': 'Critical',
        'Cancelar': 'Cancel',
        'Enviar Ticket': 'Submit Ticket',
        'Sincronizando trazabilidad técnica...': 'Syncing technical traceability...',
        'Abierto': 'Open',
        'Cerrado': 'Closed',
        'En Proceso': 'In Progress',
        'Pendiente': 'Pending',

        'Incidente original:': 'Original incident:',
        '✔ Estado: Resuelto / Atendido': '✔ Status: Resolved / Handled',
        'Diagnóstico del técnico:': 'Technician\'s diagnosis:',
        'Solución aplicada:': 'Solution applied:',
        '⏳ Estado: El ticket ha sido entregado al personal': '⏳ Status: The ticket has been delivered to staff',
        'Pendiente de revisión técnica en la bandeja global.': 'Pending technical review in the global inbox.',

        'Caja de Tickets - TechFlow': 'Ticket Box - TechFlow',
        'Buscar en la fila por código o título...': 'Search the queue by code or title...',
        '¡Incidencia resuelta con éxito! El diagnóstico fue guardado y el ticket se ha cerrado correctamente.':
            'Incident resolved successfully! The diagnosis was saved and the ticket has been closed.',
        'Bandeja de Tickets Globales': 'Global Ticket Inbox',
        'Interactúa y soluciona los requerimientos técnicos de la infraestructura corporativa.':
            'Interact with and resolve the technical requests of the corporate infrastructure.',
        'Solicitado por:': 'Requested by:',
        'Fila de operaciones limpia': 'Operations queue clear',
        'No hay tickets pendientes por resolver en este momento. 🎉': 'There are no pending tickets to resolve right now. 🎉',
        'Resolución de Incidencia': 'Incident Resolution',
        'Selecciona un ticket entrante de la fila izquierda para aplicar los parámetros de ingeniería.':
            'Select an incoming ticket from the left queue to apply the engineering parameters.',
        'Diagnóstico Técnico Oficial': 'Official Technical Diagnosis',
        'Describe la evaluación de la falla o anomalía encontrada...': 'Describe the assessment of the fault or anomaly found...',
        'Mitigación / Acción de Cierre': 'Mitigation / Closing Action',
        'Escribe los procedimientos correctivos o la solución de ingeniería aplicada...':
            'Write the corrective procedures or the engineering solution applied...',
        'Almacenar y Solucionar Caso': 'Save and Resolve Case',
        'Caso en Gestión': 'Case in Progress',

        'Inventario TI - TechFlow': 'IT Inventory - TechFlow',
        'Filtrar hardware...': 'Filter hardware...',
        '¡Equipo registrado correctamente en la base de datos!': 'Equipment registered successfully in the database!',
        'Error: El código de inventario (Asset Tag) ya existe.': 'Error: The inventory code (Asset Tag) already exists.',
        'Inventario de Equipos Tecnológicos': 'Technology Equipment Inventory',
        'Registrar nuevo equipo': 'Register new equipment',
        'Especificaciones': 'Specifications',
        'Trazabilidad': 'Traceability',
        'Estado': 'Status',
        'No asignada': 'Not assigned',
        'Operativo': 'Operational',
        'Mantenimiento': 'Maintenance',
        'De baja': 'Decommissioned',
        'El inventario está en blanco': 'The inventory is empty',
        'Registrar Nuevo Activo TI': 'Register New IT Asset',
        'Código Inventario (Asset Tag)*': 'Inventory Code (Asset Tag)*',
        'Nombre del Equipo*': 'Equipment Name*',
        'Tipo de Equipo': 'Equipment Type',
        'Marca': 'Brand',
        'Modelo': 'Model',
        'Número de Serie': 'Serial Number',
        'Ubicación': 'Location',
        'Estado Inicial': 'Initial Status',
        'Guardar Equipo': 'Save Equipment',
        'Ej: INV-2026-001': 'e.g. INV-2026-001',
        'Ej: Laptop HP ProBook': 'e.g. HP ProBook Laptop',
        'Ej: Portátil, Servidor, Switch': 'e.g. Laptop, Server, Switch',
        'Ej: HP': 'e.g. HP',
        'Ej: 450 G8': 'e.g. 450 G8',
        'Ej: CND12345XYZ': 'e.g. CND12345XYZ',
        'Ej: Oficina Central': 'e.g. Head Office',

        'Gestión de Usuarios - TechFlow': 'User Management - TechFlow',
        'Control de Usuarios y Roles': 'User & Roles Control',
        'Buscar usuario...': 'Search user...',
        'Todos los Roles': 'All Roles',
        'Administrador': 'Administrator',
        'Técnico': 'Technician',
        'Tecnico': 'Technician',
        'Standard': 'Standard',
        'Correo': 'Email',
        'Rol': 'Role',
        'Acciones': 'Actions',
        'Editar Rol': 'Edit Role',
        'Eliminar Usuario': 'Delete User',
        'Error al guardar el número de rol en la base de datos.': 'Error saving the role number in the database.',
        'Rol inválido.': 'Invalid role.',
        'No puedes eliminar a tu propio usuario administrador activo.': 'You cannot delete your own active administrator user.',
        'Usuario eliminado correctamente de la base de datos.': 'User successfully deleted from the database.',
        'No se pudo eliminar el registro.': 'The record could not be deleted.',
        'No se puede eliminar: el usuario tiene registros asociados.': 'Cannot delete: the user has associated records.',
        'No puedes quitarte tu propio rol de administrador.': 'You cannot remove your own administrator role.',

        'Credenciales incorrectas.': 'Incorrect credentials.',
        'Demasiados intentos fallidos. Intenta de nuevo en un momento.': 'Too many failed attempts. Please try again in a moment.',
        'La contraseña debe tener al menos 8 caracteres.': 'The password must be at least 8 characters long.',
        'El correo electrónico no es válido.': 'The email address is not valid.',
        'Hubo un error al guardar en la base de datos.': 'There was an error saving to the database.',
        'Sesión inválida. Recarga la página e inténtalo de nuevo.': 'Invalid session. Reload the page and try again.',
        'No tienes permisos para realizar esta acción.': 'You do not have permission to perform this action.',
        'Error de conexión con el servidor.': 'Server connection error.',
        'Ticket no encontrado.': 'Ticket not found.',
        'No se pudo cargar el seguimiento.': 'Could not load the ticket progress.',
        '← Volver': '← Back',

        'Ticket creado correctamente.': 'Ticket created successfully.',
        'Error al guardar el ticket.': 'Error saving the ticket.',
        'Completa el título y la descripción.': 'Please fill in the title and description.',
        'Este ticket ya fue resuelto por otro técnico.': 'This ticket was already resolved by another technician.',
        'Completa los campos obligatorios.': 'Please fill in the required fields.',
        'Error al guardar el equipo en la base de datos.': 'Error saving the equipment to the database.',
        'Contraseña de autorización': 'Authorization password',
        'Contraseña de autorización incorrecta.': 'Incorrect authorization password.',
        'Ingresa la contraseña de autorización para este rol.': 'Enter the authorization password for this role.',
        'Solo personal autorizado puede registrarse con este rol.': 'Only authorized staff can register with this role.',
        'Rol de acceso inválido.': 'Invalid access role.',
        'Contraseña de autorización del rol': 'Role authorization password',
        'Desconectarse': 'Logout'
    };

    const PATTERNS = [
        [/^Evolución del Caso #(\d+)$/, m => 'Case #' + m[1] + ' Progress'],
        [/^Atendido por: (.+)$/, m => 'Handled by: ' + m[1]],
        [/^Usuario: (.+)$/, m => 'User: ' + m[1]],
        [/^¿Estás seguro de que deseas eliminar al usuario '(.*)'\?$/, m => "Are you sure you want to delete user '" + m[1] + "'?"],
        [/^¡Rol guardado con éxito como \((\d+)\) en la BD!$/, m => 'Role saved successfully as (' + m[1] + ') in the DB!'],
        [/^Hubo un error al guardar en la base de datos: (.*)$/, m => 'There was an error saving to the database: ' + m[1]],
        [/^Error en la conexión: (.*)$/, m => 'Connection error: ' + m[1]]
    ];

    const ATTRS = ['placeholder', 'title', 'aria-label', 'alt'];
    const SKIP_TAGS = new Set(['SCRIPT', 'STYLE', 'NOSCRIPT', 'TEXTAREA', 'CODE', 'PRE']);
    const norm = s => s.replace(/\s+/g, ' ').trim();

    const MAP = new Map();
    Object.keys(DICT).forEach(k => MAP.set(norm(k).toLowerCase(), DICT[k]));

    let lang = 'es';
    try { lang = localStorage.getItem('lang') === 'en' ? 'en' : 'es'; } catch (e) {}

    // Evita ver un instante la página en español al cambiar de sección con idioma EN
    if (lang === 'en') {
        const st = document.createElement('style');
        st.id = 'i18n-antiflash';
        st.textContent = 'html.i18n-pending body{visibility:hidden}';
        document.head.appendChild(st);
        document.documentElement.classList.add('i18n-pending');
        setTimeout(() => document.documentElement.classList.remove('i18n-pending'), 1500);
    }

    const listeners = [];
    const missingSet = new Set();
    const textRec = new WeakMap();
    const attrRec = new WeakMap();

    function toEN(text) {
        const key = norm(text);
        if (!key) return null;
        const hit = MAP.get(key.toLowerCase());
        if (hit !== undefined) return hit;
        for (const [re, fn] of PATTERNS) {
            const m = key.match(re);
            if (m) return fn(m);
        }
        return null;
    }

    function t(str) {
        if (lang !== 'en' || typeof str !== 'string') return str;
        const en = toEN(str);
        return en === null ? str : en;
    }

    function isIgnored(el) {
        if (!el || el.nodeType !== 1) return false;
        if (SKIP_TAGS.has(el.nodeName)) return true;
        return !!(el.closest && el.closest('.material-icons, [data-no-i18n], [data-en]'));
    }

    function applyText(node) {
        const parent = node.parentNode;
        if (!parent || parent.nodeType !== 1) return;
        if (isIgnored(parent)) return;

        let rec = textRec.get(node);
        if (!rec && lang === 'es') return;

        const orig = (rec && node.nodeValue === rec.shown) ? rec.orig : node.nodeValue;
        let out = orig;

        if (lang === 'en') {
            const en = toEN(orig);
            if (en !== null) {
                const lead = orig.match(/^\s*/)[0];
                const trail = orig.match(/\s*$/)[0];
                out = lead + en + trail;
            } else if (/[A-Za-zÁÉÍÓÚÑáéíóúñ]{2,}/.test(orig)) {
                missingSet.add(norm(orig));
            }
        }
        if (out !== node.nodeValue) node.nodeValue = out;
        textRec.set(node, { orig: orig, shown: out });
    }

    function applyAttrs(el) {
        for (const a of ATTRS) {
            if (!el.hasAttribute(a)) continue;
            let rec = attrRec.get(el);
            if (!rec) {
                if (lang === 'es') continue;
                rec = {};
                attrRec.set(el, rec);
            }
            const cur = el.getAttribute(a);
            const r = rec[a];
            const orig = (r && cur === r.shown) ? r.orig : cur;
            let out = orig;
            if (lang === 'en') {
                const en = toEN(orig);
                if (en !== null) out = en;
                else if (/[A-Za-zÁÉÍÓÚÑáéíóúñ]{2,}/.test(orig)) missingSet.add(norm(orig));
            }
            if (out !== cur) el.setAttribute(a, out);
            rec[a] = { orig: orig, shown: out };
        }
    }

    function applyDataLang(el) {
        if (!el.hasAttribute('data-en')) return;
        if (!('__i18nOrig' in el)) el.__i18nOrig = el.textContent;
        let v = lang === 'en' ? el.getAttribute('data-en') : el.getAttribute('data-es');
        if (v === null) v = el.__i18nOrig;
        if (el.textContent !== v) el.textContent = v;
    }

    function walk(root) {
        if (!root) return;
        if (root.nodeType === 3) { applyText(root); return; }
        if (root.nodeType !== 1 || root.nodeName === 'SCRIPT' || root.nodeName === 'STYLE') return;

        applyAttrs(root);
        applyDataLang(root);

        const tw = document.createTreeWalker(root, NodeFilter.SHOW_ELEMENT | NodeFilter.SHOW_TEXT, {
            acceptNode(n) {
                if (n.nodeType === 1 && (n.nodeName === 'SCRIPT' || n.nodeName === 'STYLE')) return NodeFilter.FILTER_REJECT;
                return NodeFilter.FILTER_ACCEPT;
            }
        });
        let n;
        while ((n = tw.nextNode())) {
            if (n.nodeType === 3) applyText(n);
            else { applyAttrs(n); applyDataLang(n); }
        }
    }

    const observer = new MutationObserver(muts => {
        observer.disconnect();
        for (const m of muts) {
            if (m.type === 'childList') m.addedNodes.forEach(walk);
            else if (m.type === 'characterData') applyText(m.target);
            else if (m.type === 'attributes') applyAttrs(m.target);
        }
        observe();
    });
    function observe() {
        observer.observe(document.documentElement, {
            childList: true, subtree: true, characterData: true,
            attributes: true, attributeFilter: ATTRS
        });
    }

    function applyAll() {
        observer.disconnect();
        walk(document.documentElement);
        observe();
    }

    function updateButtons() {
        document.querySelectorAll('#btn-es, #btn-en, .js-lang-es, .js-lang-en').forEach(b => {
            const esEN = (b.id === 'btn-en' || b.classList.contains('js-lang-en'));
            b.classList.toggle('active', esEN ? lang === 'en' : lang === 'es');
        });
    }

    function setLang(l) {
        lang = l === 'en' ? 'en' : 'es';
        try { localStorage.setItem('lang', lang); } catch (e) {}
        document.documentElement.setAttribute('lang', lang);
        updateButtons();
        applyAll();
        listeners.forEach(fn => { try { fn(lang); } catch (e) { console.error(e); } });
    }

    const nativeAlert = window.alert.bind(window);
    const nativeConfirm = window.confirm.bind(window);
    window.alert = msg => nativeAlert(t(String(msg)));
    window.confirm = msg => nativeConfirm(t(String(msg)));

    document.addEventListener('click', e => {
        const b = e.target.closest && e.target.closest('#btn-es, #btn-en, .js-lang-es, .js-lang-en');
        if (b) setLang((b.id === 'btn-en' || b.classList.contains('js-lang-en')) ? 'en' : 'es');
    });

    document.addEventListener('DOMContentLoaded', () => {

        document.documentElement.setAttribute('lang', lang);
        updateButtons();
        applyAll();
        document.documentElement.classList.remove('i18n-pending');
    });

    window.i18n = {
        t: t,
        setLang: setLang,
        getLang: () => lang,
        onChange: fn => listeners.push(fn),

        missing: () => { const a = Array.from(missingSet); console.table(a); return a; }
    };
})();
