<?php

header("Location: caja_tickets.php");
exit();
