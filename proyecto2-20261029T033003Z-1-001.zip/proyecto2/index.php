<?php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/auth.php';
verificarSesion();

if (esStandard()) {
    header("Location: tickets.php");
    exit();
}

require_once __DIR__ . '/conexion.php';

$result = $conexion->query("SELECT COUNT(*) AS total FROM USUARIO");
$usuarios = $result ? intval($result->fetch_assoc()['total']) : 0;

$result = $conexion->query("SELECT COUNT(*) AS total FROM TICKET");
$tickets = $result ? intval($result->fetch_assoc()['total']) : 0;

$result = $conexion->query("
    SELECT COUNT(*) AS total
    FROM TICKET
    WHERE estado = 'Cerrado'
");
$tickets_cerrados = $result ? intval($result->fetch_assoc()['total']) : 0;

$tickets_abiertos = max(0, $tickets - $tickets_cerrados);

$result = $conexion->query("SELECT COUNT(*) AS total FROM EQUIPO");
$equipos = $result ? intval($result->fetch_assoc()['total']) : 0;
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Dashboard TI - TechFlow</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="global.js"></script>
</head>
<body style="background-color: #0f172a; margin: 0; font-family: system-ui, sans-serif;">
    <div class="dashboard-container">
        <?php include 'includes/sidebar.php'; ?>

        <main class="main-content">
            <header class="top-header" style="display: flex; justify-content: flex-end; align-items: center; padding: 15px 30px; background: #1e293b; border-bottom: 1px solid #334155;">
                <?php include 'includes/header.php'; ?>
            </header>

            <div class="content-body" style="padding: 30px; background: #0f172a; min-height: 100vh;">

                <div style="display: flex; gap: 20px; margin-bottom: 30px; flex-wrap: wrap;">

                    <div style="flex: 1; min-width: 220px; background: #1e293b; border-top: 4px solid #3b82f6; border-radius: 8px; padding: 20px; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1); text-align: center;">
                        <small style="color: #94a3b8; text-transform: uppercase; font-size: 0.75rem; font-weight: 700; letter-spacing: 0.05em;">Usuarios</small>
                        <h1 style="font-size: 2.5rem; margin: 10px 0 0 0; color: #ffffff; font-weight: 700;"><?php echo $usuarios; ?></h1>
                    </div>

                    <div style="flex: 1; min-width: 220px; background: #1e293b; border-top: 4px solid #eab308; border-radius: 8px; padding: 20px; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1); text-align: center;">
                        <small style="color: #94a3b8; text-transform: uppercase; font-size: 0.75rem; font-weight: 700; letter-spacing: 0.05em;">Tickets Totales</small>
                        <h1 style="font-size: 2.5rem; margin: 10px 0 0 0; color: #ffffff; font-weight: 700;"><?php echo $tickets; ?></h1>
                    </div>

                    <div style="flex: 1; min-width: 220px; background: #1e293b; border-top: 4px solid #22c55e; border-radius: 8px; padding: 20px; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1); text-align: center;">
                        <small style="color: #94a3b8; text-transform: uppercase; font-size: 0.75rem; font-weight: 700; letter-spacing: 0.05em;">Tickets Cerrados</small>
                        <h1 style="font-size: 2.5rem; margin: 10px 0 0 0; color: #22c55e; font-weight: 700;"><?php echo $tickets_cerrados; ?></h1>
                    </div>

                    <div style="flex: 1; min-width: 220px; background: #1e293b; border-top: 4px solid #a855f7; border-radius: 8px; padding: 20px; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1); text-align: center;">
                        <small style="color: #94a3b8; text-transform: uppercase; font-size: 0.75rem; font-weight: 700; letter-spacing: 0.05em;">Equipos Inventario</small>
                        <h1 style="font-size: 2.5rem; margin: 10px 0 0 0; color: #ffffff; font-weight: 700;"><?php echo $equipos; ?></h1>
                    </div>

                </div>

                <div style="display: flex; gap: 20px; flex-wrap: wrap;">

                    <div style="flex: 1; min-width: 300px; background: #1e293b; border: 1px solid #334155; border-radius: 12px; padding: 24px; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1);">
                        <h3 style="color: #ffffff; margin: 0 0 20px 0; font-size: 1.1rem; font-weight: 600; display: flex; align-items: center; gap: 10px;">
                            <span class="material-icons" style="color: #3b82f6;">pie_chart</span> Eficiencia de Tickets
                        </h3>
                        <div style="max-height: 220px; display: flex; justify-content: center;">
                            <canvas id="chartTickets"></canvas>
                        </div>
                    </div>

                    <div style="flex: 1.5; min-width: 350px; background: #1e293b; border: 1px solid #334155; border-radius: 12px; padding: 24px; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1);">
                        <h3 style="color: #ffffff; margin: 0 0 20px 0; font-size: 1.1rem; font-weight: 600; display: flex; align-items: center; gap: 10px;">
                            <span class="material-icons" style="color: #a855f7;">bar_chart</span> Volúmenes del Sistema
                        </h3>
                        <div style="max-height: 220px;">
                            <canvas id="chartBarras"></canvas>
                        </div>
                    </div>

                </div>

            </div>
        </main>
    </div>

    <script>

        const abiertos = <?php echo $tickets_abiertos; ?>;
        const cerrados = <?php echo $tickets_cerrados; ?>;
        const usuarios = <?php echo $usuarios; ?>;
        const equipos = <?php echo $equipos; ?>;

        const ctxDona = document.getElementById('chartTickets').getContext('2d');
        const chartDona = new Chart(ctxDona, {
            type: 'doughnut',
            data: {
                labels: ['Pendientes', 'Resueltos'],
                datasets: [{
                    data: [abiertos, cerrados],
                    backgroundColor: ['#ef4444', '#22c55e'],
                    borderWidth: 0,
                    hoverOffset: 4
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: { color: '#94a3b8', font: { size: 12 } }
                    }
                }
            }
        });

        const ctxBarras = document.getElementById('chartBarras').getContext('2d');
        const chartBarras = new Chart(ctxBarras, {
            type: 'bar',
            data: {
                labels: ['Usuarios', 'Equipos TI', 'Total Tickets'],
                datasets: [{
                    label: 'Cantidad Registrada',
                    data: [usuarios, equipos, abiertos + cerrados],
                    backgroundColor: ['#3b82f6', '#a855f7', '#eab308'],
                    borderRadius: 6,
                    borderWidth: 0,
                    barThickness: 20
                }]
            },
            options: {
                indexAxis: 'y',
                responsive: true,
                scales: {
                    x: { grid: { color: '#334155' }, ticks: { color: '#94a3b8' } },
                    y: { grid: { display: false }, ticks: { color: '#ffffff', font: { weight: 'bold' } } }
                },
                plugins: {
                    legend: { display: false }
                }
            }
        });

        function traducirGraficas() {
            chartDona.data.labels = [i18n.t('Pendientes'), i18n.t('Resueltos')];
            chartDona.update();
            chartBarras.data.labels = [i18n.t('Usuarios'), i18n.t('Equipos TI'), i18n.t('Total Tickets')];
            chartBarras.data.datasets[0].label = i18n.t('Cantidad Registrada');
            chartBarras.update();
        }
        i18n.onChange(traducirGraficas);
        traducirGraficas();
    </script>
</body>
</html>
