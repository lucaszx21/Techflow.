<?php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once 'conexion.php';
require_once 'auth.php';
verificarSesion();

if (!esAdmin()) {
    header("Location: inventario.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: inventario.php");
    exit();
}

if (!csrf_valido()) {
    header("Location: inventario.php?error=sesion");
    exit();
}

$codigo_inventario = isset($_POST['codigo_inventario']) ? trim($_POST['codigo_inventario']) : '';
$nombre_equipo     = isset($_POST['nombre_equipo']) ? trim($_POST['nombre_equipo']) : '';
$tipo_equipo       = isset($_POST['tipo_equipo']) ? trim($_POST['tipo_equipo']) : '';
$marca             = isset($_POST['marca']) ? trim($_POST['marca']) : '';
$modelo            = isset($_POST['modelo']) ? trim($_POST['modelo']) : '';
$numero_serie      = isset($_POST['numero_serie']) ? trim($_POST['numero_serie']) : '';
$ubicacion         = isset($_POST['ubicacion']) ? trim($_POST['ubicacion']) : '';
$estado            = isset($_POST['estado']) ? trim($_POST['estado']) : 'Operativo';

if (!in_array($estado, ['Operativo', 'Mantenimiento', 'De baja'], true)) {
    $estado = 'Operativo';
}

if ($codigo_inventario === '' || $nombre_equipo === '') {
    header("Location: inventario.php?error=vacios");
    exit();
}

$check = $conexion->prepare("SELECT id_equipo FROM EQUIPO WHERE codigo_inventario = ?");
$check->bind_param("s", $codigo_inventario);
$check->execute();
$duplicado = ($check->get_result()->num_rows > 0);
$check->close();

if ($duplicado) {
    header("Location: inventario.php?error=duplicado");
    exit();
}

$sql = "INSERT INTO EQUIPO (codigo_inventario, nombre_equipo, tipo_equipo, marca, modelo, numero_serie, estado, ubicacion)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

$stmt = $conexion->prepare($sql);
$stmt->bind_param("ssssssss", $codigo_inventario, $nombre_equipo, $tipo_equipo, $marca, $modelo, $numero_serie, $estado, $ubicacion);

if ($stmt->execute()) {
    header("Location: inventario.php?success=1");
} else {
    error_log("TechFlow guardar_equipo: " . $conexion->error);
    header("Location: inventario.php?error=db");
}
$stmt->close();
exit();
?>
