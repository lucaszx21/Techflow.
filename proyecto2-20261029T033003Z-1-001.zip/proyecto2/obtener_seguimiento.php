<?php

if (session_status() === PHP_SESSION_NONE) { session_start(); }
require_once 'conexion.php';
require_once 'auth.php';

header('Content-Type: text/html; charset=UTF-8');

if (!isset($_SESSION['usuario_id'])) {
    http_response_code(401);
    echo "<p>No tienes permisos para realizar esta acción.</p>";
    exit();
}

$id_ticket = isset($_GET['id']) ? intval($_GET['id']) : 0;
$id_usuario = intval($_SESSION['usuario_id']);

if (esStandard()) {
    $stmt = $conexion->prepare("SELECT * FROM TICKET WHERE id_ticket = ? AND id_usuario_creador = ?");
    $stmt->bind_param("ii", $id_ticket, $id_usuario);
} else {
    $stmt = $conexion->prepare("SELECT * FROM TICKET WHERE id_ticket = ?");
    $stmt->bind_param("i", $id_ticket);
}
$stmt->execute();
$ticket = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$ticket) {
    http_response_code(404);
    echo "<p>Ticket no encontrado.</p>";
    exit();
}

echo "<h3>Evolución del Caso #" . intval($ticket['id_ticket']) . "</h3>";
echo "<p style='margin-top:8px;'><strong>Incidente original:</strong> " . esc($ticket['descripcion']) . "</p>";
echo "<hr style='border:0; border-top:1px solid #334155; margin:12px 0;'>";

$sql_d = "SELECT d.*, u.nombre, u.apellido FROM DIAGNOSTICO d
          INNER JOIN USUARIO u ON d.id_tecnico = u.id_usuario
          WHERE d.id_ticket = ? LIMIT 1";
$stmt_d = $conexion->prepare($sql_d);
$stmt_d->bind_param("i", $id_ticket);
$stmt_d->execute();
$res_d = $stmt_d->get_result();

if ($res_d && $res_d->num_rows === 1) {
    $diag = $res_d->fetch_assoc();
    echo "<div style='background:rgba(34,197,94,0.12); border-left:4px solid #16a34a; padding:12px; border-radius:4px;'>";
    echo "<strong style='color:#4ade80;'>✔ Estado: Resuelto / Atendido</strong>";
    echo "<p style='margin: 6px 0; font-size:0.9rem;'><strong>Diagnóstico del técnico:</strong> " . esc($diag['diagnostico']) . "</p>";
    echo "<p style='margin: 6px 0; font-size:0.9rem;'><strong>Solución aplicada:</strong> " . esc($diag['solucion']) . "</p>";
    echo "<small style='color:#94a3b8; font-size:0.75rem;'>Atendido por: " . esc($diag['nombre'] . " " . $diag['apellido']) . "</small>";
    echo "</div>";
} else {
    echo "<div style='background:rgba(234,179,8,0.12); border-left:4px solid #d97706; padding:12px; border-radius:4px;'>";
    echo "<strong style='color:#facc15;'>⏳ Estado: El ticket ha sido entregado al personal</strong>";
    echo "<p style='font-size:0.85rem; color:#94a3b8; margin-top:4px;'>Pendiente de revisión técnica en la bandeja global.</p>";
    echo "</div>";
}
$stmt_d->close();
?>
