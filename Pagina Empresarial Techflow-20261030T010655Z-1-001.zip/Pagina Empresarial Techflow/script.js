/* ================================================================
   TECHFLOW — script.js
   ================================================================
   ANIMACIÓN DE ENTRADA — fundamento físico
   ----------------------------------------------------------------
   Se usa la ecuación del MOVIMIENTO RECTILÍNEO UNIFORMEMENTE
   ACELERADO (MRUA), la misma que ves en cinemática básica:

        s(t) = s0 + v0·t + (1/2)·a·t²

   donde:
        s0  -> posición inicial (aquí: 0, el eje del gráfico)
        v0  -> velocidad inicial (aquí: 0, parte del reposo)
        a   -> aceleración constante (distinta para cada barra)
        t   -> tiempo transcurrido

   Cada barra del gráfico es un "objeto" que parte del reposo
   (v0 = 0, s0 = 0) y asciende con una aceleración "a" propia.
   Como s(t) depende de t², el ascenso no es a velocidad
   constante: cada barra empieza lenta y se acelera, tal como
   describe la fórmula. Al llegar a su altura objetivo, el
   movimiento se detiene (choca con su "techo").
   ================================================================ */

(function initIntroAnimation(){
  const canvas = document.getElementById('physics-canvas');
  const overlay = document.getElementById('intro-overlay');
  const skipBtn = document.getElementById('skip-intro');
  const ctx = canvas.getContext('2d');

  function resizeCanvas(){
    const rect = canvas.getBoundingClientRect();
    canvas.width = rect.width * devicePixelRatio;
    canvas.height = rect.height * devicePixelRatio;
    ctx.setTransform(devicePixelRatio, 0, 0, devicePixelRatio, 0, 0);
  }
  resizeCanvas();
  window.addEventListener('resize', resizeCanvas);

  const w = canvas.width / devicePixelRatio;
  const h = canvas.height / devicePixelRatio;

  // --- Márgenes y ejes del gráfico ---
  const margin = { left: 56, right: 24, top: 30, bottom: 46 };
  const chartW = w - margin.left - margin.right;
  const chartH = h - margin.top - margin.bottom;
  const baseY = h - margin.bottom;

  // --- Barras: cada una es un objeto en MRUA, s0 = 0, v0 = 0 ---
  const N_BARS = 9;
  const barGap = chartW / N_BARS;
  const barWidth = barGap * 0.55;

  // alturas objetivo con tendencia ascendente (como crecimiento real)
  const targetHeights = [0.18, 0.24, 0.22, 0.34, 0.4, 0.5, 0.62, 0.8, 0.98];

  const bars = targetHeights.map((factor, i) => {
    const targetH = chartH * factor;
    // distancia a recorrer = targetH -> se despeja "a" para que cada
    // barra llegue a su objetivo en un tiempo de referencia distinto,
    // dando el efecto de aceleración creciente y en cascada.
    const tArrival = 1.0 + i * 0.18;               // tiempo de llegada (s)
    const a = (2 * targetH) / (tArrival * tArrival); // despejado de s = 1/2 a t²
    return {
      x: margin.left + i * barGap + (barGap - barWidth) / 2,
      targetH,
      a,
      tArrival
    };
  });

  // --- Loop de animación ---
  let startTime = null;
  const DURATION = 3.0; // segundos totales de la escena
  let rafId = null;

  function drawAxes(){
    ctx.strokeStyle = 'rgba(255,255,255,0.25)';
    ctx.lineWidth = 1.5;
    // eje Y
    ctx.beginPath();
    ctx.moveTo(margin.left, margin.top);
    ctx.lineTo(margin.left, baseY);
    ctx.stroke();
    // eje X
    ctx.beginPath();
    ctx.moveTo(margin.left, baseY);
    ctx.lineTo(w - margin.right, baseY);
    ctx.stroke();

    ctx.fillStyle = 'rgba(255,255,255,0.55)';
    ctx.font = "12px 'JetBrains Mono', monospace";
    ctx.textAlign = 'center';
    ctx.fillText('tiempo (t)', margin.left + chartW / 2, h - 14);
    ctx.save();
    ctx.translate(18, margin.top + chartH / 2);
    ctx.rotate(-Math.PI / 2);
    ctx.fillText('crecimiento s(t)', 0, 0);
    ctx.restore();
  }

  function draw(now){
    if (!startTime) startTime = now;
    const t = (now - startTime) / 1000;

    ctx.clearRect(0, 0, w, h);
    drawAxes();

    let allDone = true;
    const topPoints = [];

    bars.forEach((bar) => {
      // s(t) = s0 + v0*t + 1/2*a*t², con s0 = 0, v0 = 0
      const raw = 0.5 * bar.a * t * t;
      const height = Math.min(raw, bar.targetH);
      if (height < bar.targetH) allDone = false;

      const barTop = baseY - height;
      const progress = height / bar.targetH;

      const grad = ctx.createLinearGradient(0, barTop, 0, baseY);
      grad.addColorStop(0, '#4FC3F7');
      grad.addColorStop(1, '#1657D6');
      ctx.fillStyle = grad;
      ctx.globalAlpha = 0.4 + 0.6 * progress;
      ctx.fillRect(bar.x, barTop, barWidth, height);
      ctx.globalAlpha = 1;

      topPoints.push({ x: bar.x + barWidth / 2, y: barTop });
    });

    // línea de tendencia conectando las puntas (curva de crecimiento)
    if (topPoints.length > 1){
      ctx.beginPath();
      ctx.moveTo(topPoints[0].x, topPoints[0].y);
      for (let i = 1; i < topPoints.length; i++){
        ctx.lineTo(topPoints[i].x, topPoints[i].y);
      }
      ctx.strokeStyle = '#FFFFFF';
      ctx.lineWidth = 2;
      ctx.setLineDash([4, 4]);
      ctx.stroke();
      ctx.setLineDash([]);

      // punto final destacado
      const last = topPoints[topPoints.length - 1];
      ctx.beginPath();
      ctx.arc(last.x, last.y, 4, 0, Math.PI * 2);
      ctx.fillStyle = '#FFFFFF';
      ctx.fill();
    }

    if (t < DURATION || !allDone){
      rafId = requestAnimationFrame(draw);
    } else {
      setTimeout(endIntro, 800);
    }
  }

  function endIntro(){
    overlay.classList.add('hide');
    document.body.style.overflow = 'auto';
  }

  document.body.style.overflow = 'hidden';
  rafId = requestAnimationFrame(draw);

  skipBtn.addEventListener('click', () => {
    cancelAnimationFrame(rafId);
    endIntro();
  });
})();


/* ================================================================
   HERO — animación ambiental de onda
   ----------------------------------------------------------------
   Ecuación de onda armónica viajera (representa el "flujo" de datos):

        y(x, t) = A · sin(k x - ω t + φ)

   donde k = 2π/λ (número de onda) y ω = 2π f (frecuencia angular).
   Se suman varias ondas con distinta amplitud/longitud (principio
   de superposición) para lograr un movimiento más orgánico.
   ================================================================ */
(function initHeroWave(){
  const canvas = document.getElementById('hero-wave');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');

  function resize(){
    const rect = canvas.getBoundingClientRect();
    canvas.width = rect.width * devicePixelRatio;
    canvas.height = rect.height * devicePixelRatio;
    ctx.setTransform(devicePixelRatio, 0, 0, devicePixelRatio, 0, 0);
  }
  resize();
  window.addEventListener('resize', resize);

  const waves = [
    { A: 18, lambda: 220, speed: 0.9,  color: 'rgba(22,87,214,0.35)' },
    { A: 26, lambda: 340, speed: 0.55, color: 'rgba(79,195,247,0.45)' },
    { A: 12, lambda: 150, speed: 1.3,  color: 'rgba(11,61,145,0.25)' }
  ];

  let t0 = null;
  function frame(now){
    if (!t0) t0 = now;
    const t = (now - t0) / 1000;
    const w = canvas.width / devicePixelRatio;
    const h = canvas.height / devicePixelRatio;

    ctx.clearRect(0, 0, w, h);

    waves.forEach((wave, i) => {
      const k = (2 * Math.PI) / wave.lambda;
      const omega = wave.speed;
      ctx.beginPath();
      for (let x = 0; x <= w; x += 4){
        const y = h / 2 + wave.A * Math.sin(k * x - omega * t + i) ;
        if (x === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
      }
      ctx.strokeStyle = wave.color;
      ctx.lineWidth = 2;
      ctx.stroke();
    });

    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);
})();


/* ================================================================
   Navbar: resaltar link activo al hacer scroll (utilidad simple)
   ================================================================ */
(function highlightNavOnScroll(){
  const sections = document.querySelectorAll('section[id]');
  const links = document.querySelectorAll('.nav-links a[href^="#"]');

  window.addEventListener('scroll', () => {
    let current = '';
    sections.forEach(sec => {
      const top = sec.offsetTop - 120;
      if (window.scrollY >= top) current = sec.getAttribute('id');
    });
    links.forEach(link => {
      link.style.color = link.getAttribute('href') === `#${current}` ? '#1657D6' : '';
    });
  });
})();
